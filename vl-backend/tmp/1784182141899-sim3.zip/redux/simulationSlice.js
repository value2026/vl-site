import { createSlice, createSelector } from '@reduxjs/toolkit';

const initialState = {
  step: 1,
  jobs: [
    { id: 1, name: "Frontend Dev", duration: 3, machine: "Machine 1", sector: "IT" },
    { id: 2, name: "Backend Dev", duration: 5, machine: "Machine 2", sector: "IT" },
    { id: 3, name: "Database Admin", duration: 4, machine: "Machine 1", sector: "IT" },
    { id: 4, name: "Cloud Engineer", duration: 6, machine: "Machine 3", sector: "IT" },
    { id: 5, name: "Cyber Security", duration: 2, machine: "Machine 2", sector: "IT" },
  ],
  nextId: 6,
  dependencyConstraints: [],
  theta: {},
  energy: 0,
  schedule: [],
  energyHistory: [],
  thetaHistory: [],
  machines: ["Machine 1", "Machine 2", "Machine 3"],
  suggestedJobNames: ["Assembly Task", "Quality Check", "Packaging Run", "Calibration Cycle", "Maintenance Job"],
  optimizationStarted: false,
};

export const simulationSlice = createSlice({
  name: 'simulation',
  initialState,
  reducers: {
    setStep: (state, action) => {
      state.step = action.payload;
    },
    setJobs: (state, action) => {
      state.jobs = action.payload;
    },
    setNextId: (state, action) => {
      state.nextId = action.payload;
    },
    setDependencyConstraints: (state, action) => {
      state.dependencyConstraints = action.payload;
    },
    setTheta: (state, action) => {
      state.theta = action.payload;
    },
    setEnergy: (state, action) => {
      state.energy = action.payload;
    },
    setSchedule: (state, action) => {
      state.schedule = action.payload;
    },
    setEnergyHistory: (state, action) => {
      state.energyHistory = action.payload;
    },
    setThetaHistory: (state, action) => {
      state.thetaHistory = action.payload;
    },
    addJob: (state, action) => {
      state.jobs.push(action.payload);
      state.nextId += 1;
    },
    updateJob: (state, action) => {
      const index = state.jobs.findIndex(job => job.id === action.payload.id);
      if (index !== -1) {
        state.jobs[index] = action.payload;
      }
    },
    deleteJob: (state, action) => {
      state.jobs = state.jobs.filter(job => job.id !== action.payload);
    },
    addDependency: (state, action) => {
        state.dependencyConstraints.push(action.payload);
    },
    removeDependency: (state, action) => {
      state.dependencyConstraints.splice(action.payload, 1);
    },
    setOptimizationStarted: (state, action) => {
      state.optimizationStarted = action.payload;
    },
    addEnergyHistoryEntry: (state, action) => {
      state.energyHistory.push(action.payload);
    },
    addThetaHistoryEntry: (state, action) => {
      state.thetaHistory.push(action.payload);
    }
  },
});

export const {
  setStep,
  setJobs,
  setNextId,
  setDependencyConstraints,
  setTheta,
  setEnergy,
  setSchedule,
  setEnergyHistory,
  setThetaHistory,
  addJob,
  updateJob,
  deleteJob,
  addDependency,
  removeDependency,
  setOptimizationStarted,
  addEnergyHistoryEntry,
  addThetaHistoryEntry,
} = simulationSlice.actions;

const selectJobs = (state) => state.simulation.jobs;
const selectDependencyConstraints = (state) => state.simulation.dependencyConstraints;
const selectMachines = (state) => state.simulation.machines;
const selectTheta = (state) => state.simulation.theta;

export const selectHamiltonian = createSelector(
  [selectJobs, selectDependencyConstraints],
  (jobs, dependencyConstraints) => {
    const terms = ["H ="];
    dependencyConstraints.forEach(d => {
      const from = jobs.find(j => j.id === d.firstJobId)?.name || `J${d.firstJobId}`;
      const to = jobs.find(j => j.id === d.secondJobId)?.name || `J${d.secondJobId}`;
      terms.push(`+1.0 * Order(${from}, ${to})`);
    });
    return terms;
  }
);

export const selectPreviewSchedule = createSelector(
  [selectJobs, selectDependencyConstraints, selectMachines],
  (jobs, deps, machines) => {
    if (!jobs.length) return [];
    const adj = new Map(jobs.map(j => [j.id, []]));
    const inDegree = new Map(jobs.map(j => [j.id, 0]));
    deps.forEach(d => {
      if (adj.has(d.firstJobId)) {
        adj.get(d.firstJobId).push(d.secondJobId);
        inDegree.set(d.secondJobId, (inDegree.get(d.secondJobId) || 0) + 1);
      }
    });
    const queue = jobs.filter(j => inDegree.get(j.id) === 0).map(j => j.id);
    const order = [];
    while (queue.length) {
      const id = queue.shift();
      order.push(id);
      if (adj.has(id)) {
        adj.get(id).forEach(n => {
          inDegree.set(n, inDegree.get(n) - 1);
          if (inDegree.get(n) === 0) queue.push(n);
        });
      }
    }
    order.push(...jobs.filter(j => !order.includes(j.id)).map(j => j.id));

    const machineEnd = new Map(machines.map(m => [m, 0]));
    const schedule = [];

    order.forEach(id => {
      const job = jobs.find(j => j.id === id);
      if (!job) return;
      let earliest = 0;
      deps.forEach(d => {
        if (d.secondJobId === id) {
          const pred = schedule.find(s => s.jobId === d.firstJobId);
          if (pred) earliest = Math.max(earliest, pred.start + pred.duration);
        }
      });
      const start = Math.max(earliest, machineEnd.get(job.machine) || 0);
      schedule.push({ jobId: id, start, duration: job.duration });
      machineEnd.set(job.machine, start + job.duration);
    });
    return schedule;
  }
);

export const selectDecodedTheta = createSelector(
  [selectTheta, selectJobs],
  (theta, jobs) => {
    return Object.entries(theta)
      .map(([idx, th]) => {
        const prob = Math.sin(th) ** 2;
        const estTime = prob * 10;
        return {
          idx: parseInt(idx),
          job: jobs[parseInt(idx)],
          theta: th,
          prob,
          estTime,
        };
      })
      .sort((a, b) => a.estTime - b.estTime)
      .map((o, i) => ({ ...o, position: i + 1 }));
  }
);


export default simulationSlice.reducer;