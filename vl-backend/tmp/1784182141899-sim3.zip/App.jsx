import React, { useState } from 'react';
import JobSchedulingSimulation  from './components/JobSchedulingSimulation'
import Introduction from './Introduction'; // Corrected path
import "bootstrap/dist/css/bootstrap.min.css";

const App = () => {
  const [simulationStarted, setSimulationStarted] = useState(false);

  const handleStart = () => {
    setSimulationStarted(true);
  };

  return (
    <div>
      {simulationStarted ? (
    <JobSchedulingSimulation />
      ) : (
        <Introduction onStart={handleStart} />
      )}

    </div>
  );
}

export default App;
