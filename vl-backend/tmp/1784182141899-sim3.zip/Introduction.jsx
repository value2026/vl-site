// src/Introduction.jsx
import React from 'react';
import {
  Container,
  Button,
  Card,
  CardContent,
  Typography,
  Box,
  Stack,
  useTheme,
  alpha,
} from '@mui/material';
import { PlayArrow } from '@mui/icons-material';

const Introduction = ({ onStart }) => {
  const theme = useTheme();

  return (
    <Container
      component="main"
      maxWidth="md"
      sx={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        py: { xs: 4, md: 6 },
        background: 'transparent',
      }}
    >
      <Card
        raised
        sx={{
          maxWidth: 680,
          width: '100%',
          p: { xs: 3, sm: 5 },
          borderRadius: 4,
          background: `linear-gradient(to bottom right, ${theme.palette.background.paper}, ${alpha(
            theme.palette.primary.light,
            0.03
          )})`,
          boxShadow: `0 12px 32px ${alpha(theme.palette.common.black, 0.12)}`,
          position: 'relative',
          overflow: 'visible',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: -12,
            left: -12,
            right: -12,
            bottom: -12,
            background: `radial-gradient(circle at 20% 80%, ${alpha(
              theme.palette.primary.main,
              0.15
            )}, transparent 70%)`,
            zIndex: -1,
            borderRadius: 'inherit',
          },
        }}
      >
        <CardContent sx={{ textAlign: 'center' }}>
          {/* TITLE */}
          <Typography
            variant="h4"
            component="h3"
            gutterBottom
            sx={{
              fontWeight: 600,
              background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              letterSpacing: '-0.5px',
            }}
          >
            Variational Quantum Eigensolver
          </Typography>

          {/* MAIN INTRO TEXT */}
          <Typography
            variant="body1"
            paragraph
            sx={{ mt: 2, color: 'text.secondary', lineHeight: 1.7 }}
          >
            This simulation demonstrates, step by step, how the{' '}
            <strong>Variational Quantum Eigensolver (VQE)</strong> can be applied to solve a
            practical optimization task — <strong>job scheduling</strong>.
          </Typography>

          <Typography
            variant="body1"
            paragraph
            sx={{ color: 'text.secondary', lineHeight: 1.7 }}
          >
            You will:
            <Box component="span" display="block" sx={{ mt: 0.5 }}>
              • Encode constraints and costs into a Hamiltonian. <br />
              • Build a parameterized quantum circuit (ansatz). <br />
              • Run a VQE loop to identify the lowest-energy schedule.
            </Box>
          </Typography>

          <Typography
            variant="body2"
            paragraph
            sx={{ color: 'text.secondary', lineHeight: 1.6 }}
          >
            Add jobs, set dependencies and priorities, and observe how each choice shapes the
            quantum optimization process.
          </Typography>

          {/* START BUTTON */}
          <Box mt={4}>
            <Button
              variant="contained"
              size="large"
              onClick={onStart}
              startIcon={<PlayArrow />}
              sx={{
                px: 5,
                py: 1.5,
                fontWeight: 600,
                borderRadius: 3,
                textTransform: 'none',
                boxShadow: `0 6px 16px ${alpha(theme.palette.primary.main, 0.3)}`,
                '&:hover': {
                  boxShadow: `0 8px 24px ${alpha(theme.palette.primary.main, 0.4)}`,
                  transform: 'translateY(-2px)',
                },
                transition: 'all 0.2s ease',
              }}
            >
              Start Simulation
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Container>
  );
};

export default Introduction;
