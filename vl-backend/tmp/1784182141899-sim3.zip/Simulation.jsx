import React, { useState, useEffect } from "react";
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  ToggleButton,
  ToggleButtonGroup,
  LinearProgress,
  Alert,
  Chip,
  Stepper,
  Step,
  StepLabel,
  Fade,
  Zoom,
  alpha,
  useTheme,
  Paper,
  IconButton,
  Divider,
} from "@mui/material";
import {
  Add as AddIcon,
  PlayArrow,
  Schedule,
  WarningAmber,
  CheckCircle,
  AutoFixHigh,
  Memory,
  Functions,
  Science,
  Delete as DeleteIcon,
  Edit as EditIcon,
  ArrowForward,
} from "@mui/icons-material";

const machines = ["Machine 1", "Machine 2", "Machine 3"];

const jobNameOptions = [
  "Software Engineer",
  "Data Analyst",
  "Network Administrator",
  "IT Support Specialist",
  "Cybersecurity Analyst",
];

// ---------- 5 default jobs ----------
const initialJobs = [
  {
    id: 1,
    name: "Frontend Dev",
    duration: 5,
    machine: "Machine 1",
    sector: "IT",
    dependencies: [],
  },
  {
    id: 2,
    name: "Backend Dev",
    duration: 5,
    machine: "Machine 2",
    sector: "IT",
    dependencies: [],
  },
  {
    id: 3,
    name: "Database Admin",
    duration: 5,
    machine: "Machine 1",
    sector: "IT",
    dependencies: [],
  },
  {
    id: 4,
    name: "Cloud Engineer",
    duration: 5,
    machine: "Machine 3",
    sector: "IT",
    dependencies: [],
  },
  {
    id: 5,
    name: "Cyber Security",
    duration: 5,
    machine: "Machine 2",
    sector: "IT",
    dependencies: [],
  },
];

const constraintOptions = [
  {
    id: "no-overlap",
    label: "No Overlap on Same Machine",
    penalty: 20,
  },
];
// Suggested job names — customize as needed
const suggestedJobNames = [
  "Assembly Task",
  "Quality Check",
  "Packaging Run",
  "Calibration Cycle",
  "Maintenance Job",
  "Testing Phase",
];
const Simulation = () => {
  const theme = useTheme();

  // ---------- State ----------
  const [step, setStep] = useState(1);
  const [jobs, setJobs] = useState(initialJobs);
  const [nextId, setNextId] = useState(initialJobs.length + 1);

  // Form fields
  const [newName, setNewName] = useState(jobNameOptions[0]);
  const [newDuration, setNewDuration] = useState(5); // Default duration to 5
  const [newMachine, setNewMachine] = useState(machines[0]);

  // Step 2
  const [activeConstraints, setActiveConstraints] = useState([]);
  const [dependencyConstraints, setDependencyConstraints] = useState([]);
  const [hamiltonian, setHamiltonian] = useState(["H = 0"]);
  const [energy, setEnergy] = useState(0);
  const [schedule, setSchedule] = useState([]);
  const [dependency, setDependency] = useState({ firstJob: "", secondJob: "" });
  // const [vqeProgress, setVqeProgress] = useState(0); // Removed unused state

  useEffect(() => {
    const newTerms = ["H ="];
    let newEnergy = 0;

    if (activeConstraints.includes("no-overlap")) {
      const machineJobs = {};
      jobs.forEach((job) => {
        if (!machineJobs[job.machine]) {
          machineJobs[job.machine] = [];
        }
        machineJobs[job.machine].push(job);
      });

      const penalty = constraintOptions.find(
        (c) => c.id === "no-overlap"
      ).penalty;

      for (const machine in machineJobs) {
        const machineJobList = machineJobs[machine];
        for (let i = 0; i < machineJobList.length; i++) {
          for (let j = i + 1; j < machineJobList.length; j++) {
            const job1 = machineJobList[i];
            const job2 = machineJobList[j];
            newTerms.push(`+ ${penalty}*${job1.name}*${job2.name}`);
            newEnergy += penalty;
          }
        }
      }
    }

    dependencyConstraints.forEach((dep) => {
      const firstJob = jobs.find((j) => j.id === dep.firstJobId);
      const secondJob = jobs.find((j) => j.id === dep.secondJobId);
      if (firstJob && secondJob) {
        const penalty = 30; // penalty for order
        newTerms.push(
          `+ ${penalty}*Order(${firstJob.name}, ${secondJob.name})`
        );
        newEnergy += penalty;
      }
    });

    if (newTerms.length === 1) newTerms.push("0");
    setHamiltonian(newTerms);
    setEnergy(newEnergy);
  }, [dependencyConstraints, activeConstraints, jobs]);

  // ---------- Add / Delete / Edit ----------
  const addJob = () => {
    if (!newName.trim() || newDuration < 1) return;
    const job = {
      id: nextId,
      name: newName.trim(),
      duration: newDuration,
      machine: newMachine,
      sector: "IT", // Automatically assign sector "IT"
      dependencies: [],
    };
    setJobs((prev) => [...prev, job]);
    setNextId((prev) => prev + 1);
    resetForm();
  };

  const deleteJob = (id) => {
    setJobs((prev) =>
      prev
        .filter((j) => j.id !== id)
        .map((j) => ({
          ...j,
          dependencies: j.dependencies.filter((depId) => depId !== id),
        }))
    );
    setDependencyConstraints((prev) =>
      prev.filter((c) => c.firstJobId !== id && c.secondJobId !== id)
    );
  };

  const resetForm = () => {
    setNewName("");
    setNewDuration(1);
    setNewMachine(machines[0]);
  };

  const addDependency = () => {
    const { firstJob, secondJob } = dependency;
    if (!firstJob || !secondJob || firstJob === secondJob) return;

    const firstJobObj = jobs.find((j) => j.id === parseInt(firstJob));
    const secondJobObj = jobs.find((j) => j.id === parseInt(secondJob));

    if (!firstJobObj || !secondJobObj) return;

    setJobs(
      jobs.map((job) => {
        if (job.id === parseInt(secondJob)) {
          if (!job.dependencies.includes(parseInt(firstJob))) {
            return {
              ...job,
              dependencies: [...job.dependencies, parseInt(firstJob)],
            };
          }
        }
        return job;
      })
    );

    const newConstraint = {
      firstJobId: firstJobObj.id,
      secondJobId: secondJobObj.id,
    };
    setDependencyConstraints((prev) => [...prev, newConstraint]);

    setDependency({ firstJob: "", secondJob: "" });
  };

  // ---------- Constraint handling ----------
  const handleConstraintChange = (event, newConstraints) => {
    setActiveConstraints(newConstraints);
  };

  const runTopologicalSort = () => {
    const inDegree = new Map();
    const adj = new Map();
    const schedule = [];
    const machineTimes = {};
    machines.forEach((m) => {
      machineTimes[m] = 0;
    });

    for (const job of jobs) {
      inDegree.set(job.id, 0);
      adj.set(job.id, []);
    }

    for (const job of jobs) {
      for (const depId of job.dependencies) {
        inDegree.set(job.id, inDegree.get(job.id) + 1);
        if (!adj.has(depId)) {
          adj.set(depId, []);
        }
        adj.get(depId).push(job.id);
      }
    }

    const queue = [];
    for (const [jobId, degree] of inDegree.entries()) {
      if (degree === 0) {
        queue.push(jobId);
      }
    }

    const jobMap = new Map(jobs.map((j) => [j.id, { ...j, startTime: 0 }]));

    while (queue.length > 0) {
      const jobId = queue.shift();
      const currentJob = jobMap.get(jobId);

      let maxDepEndTime = 0;
      for (const depId of currentJob.dependencies) {
        const depJob = schedule.find((j) => j.id === depId);
        if (depJob) {
          const depEndTime = depJob.startTime + depJob.duration;
          if (depEndTime > maxDepEndTime) {
            maxDepEndTime = depEndTime;
          }
        }
      }

      const machineAvailableTime = machineTimes[currentJob.machine] || 0;
      currentJob.startTime = Math.max(maxDepEndTime, machineAvailableTime);
      machineTimes[currentJob.machine] =
        currentJob.startTime + currentJob.duration;

      schedule.push(currentJob);

      if (adj.has(jobId)) {
        for (const neighborId of adj.get(jobId)) {
          inDegree.set(neighborId, inDegree.get(neighborId) - 1);
          if (inDegree.get(neighborId) === 0) {
            queue.push(neighborId);
          }
        }
      }
    }

    if (schedule.length !== jobs.length) {
      console.error("Circular dependency detected!");
      setSchedule([]);
      return;
    }

    const finalSchedule = schedule.map((j) => ({
      job: j.name,
      machine: j.machine,
      start: j.startTime,
      end: j.startTime + j.duration,
      valid: true,
    }));

    setSchedule(finalSchedule);
  };

  const energyColor =
    energy > 70 ? "error" : energy > 40 ? "warning" : "success";

  // -----------------------------------------------------------------
  // Re-usable panels (same as before)
  // -----------------------------------------------------------------
  const QuantumMappingPanel = () => (
    <Box sx={{ mb: 3 }}>
      <Typography
        variant="h5"
        gutterBottom
        sx={{ display: "flex", alignItems: "center", gap: 1 }}
      >
        <Science color="secondary" /> Quantum Mapping
      </Typography>
      <Paper
        elevation={4}
        sx={{
          p: 3,
          background: alpha(theme.palette.primary.dark, 0.03),
          borderRadius: 2,
        }}
      >
        <Typography variant="body1" paragraph>
          Each job to <strong>1 qubit</strong>
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {jobs.map((j, i) => (
            <div key={j.id}>
              • {j.name}: Qubit {i}
            </div>
          ))}
        </Typography>
        <Box mt={2}>
          <Chip
            icon={<Functions />}
            label={`${jobs.length} qubits total`}
            color="primary"
          />
        </Box>
      </Paper>
    </Box>
  );

  const QuantumStatusPanel = () => (
    <Box>
      <Typography
        variant="h5"
        gutterBottom
        sx={{ display: "flex", alignItems: "center", gap: 1 }}
      >
        <Science color="secondary" /> Quantum Status
      </Typography>
      <Paper
        elevation={4}
        sx={{
          p: 3,
          background: alpha(theme.palette.primary.dark, 0.03),
          borderRadius: 2,
          display: "flex",
          flexDirection: "column",
          gap: 2.5,
        }}
      >
        {/* Symbolic Hamiltonian */}
        <Box>
          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
            The Hamiltonian (in terms of Pauli Gates)
          </Typography>
          <Typography variant="body2" sx={{ fontFamily: "monospace", mb: 1 }}>
            H = Σ J_ij (Z_i ⊗ Z_j)
          </Typography>
          <Typography variant="caption" component="div" color="text.secondary">
            This is the cost function in a form a quantum computer can
            understand.
            <ul style={{ paddingLeft: 20, marginTop: 4 }}>
              <li>
                <code>H</code>: The Hamiltonian, representing the total energy
                of the system.
              </li>
              <li>
                <code>Z_i</code>: The Pauli-Z gate acting on qubit{" "}
                <code>i</code>. It represents whether a job is scheduled.
              </li>
              <li>
                <code>J_ij</code>: The coupling strength between qubit{" "}
                <code>i</code> and <code>j</code>. This is the penalty value for
                a constraint violation.
              </li>
              <li>
                <code>⊗</code>: The tensor product, a way of combining operators
                acting on different qubits.
              </li>
            </ul>
          </Typography>
        </Box>

        {/* Calculated Hamiltonian */}
        <Box>
          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
            Problem-Specific Hamiltonian
          </Typography>
          <Typography
            variant="body2"
            sx={{
              color: energy > 0 ? "primary.main" : "text.secondary",
              whiteSpace: "pre-wrap",
              wordBreak: "break-word",
              fontFamily: "monospace",
              bgcolor: "background.default",
              p: 1.5,
              borderRadius: 1,
              border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
            }}
          >
            {hamiltonian.join(" ")}
          </Typography>
        </Box>

        {/* Energy */}
        <Box>
          <Typography variant="subtitle2" color="text.secondary" gutterBottom>
            Energy Level
          </Typography>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <LinearProgress
              variant="determinate"
              value={Math.min(energy, 100)}
              color={energyColor}
              sx={{ flex: 1, height: 8, borderRadius: 4 }}
            />
            <Chip
              label={`${energy}%`}
              color={energyColor}
              size="small"
              sx={{ fontWeight: 600 }}
            />
          </Box>
        </Box>
      </Paper>
    </Box>
  );

  const ScheduleTimeline = ({ schedule }) => {
    if (!schedule || schedule.length === 0) {
      return <Typography>No schedule to display.</Typography>;
    }

    const maxTime = schedule.reduce((max, s) => Math.max(max, s.end), 0);

    return (
      <Box>
        <Typography variant="h5" gutterBottom>
          Schedule Timeline
        </Typography>
        <Paper sx={{ p: 2, position: "relative", overflowX: "auto" }}>
          {machines.map((machine) => (
            <Box key={machine} sx={{ mb: 2 }}>
              <Typography variant="subtitle1">{machine}</Typography>
              <Box
                sx={{
                  position: "relative",
                  minHeight: "90px", // Increased minHeight to allow for 2-3 lines
                  height: "auto", // Allow height to adjust based on content
                  border: "1px solid #ccc",
                  borderRadius: 1,
                }}
              >
                {schedule
                  .filter((s) => s.machine === machine)
                  .map((s, index) => {
                    const left = (s.start / maxTime) * 100;
                    const width = ((s.end - s.start) / maxTime) * 100;
                    return (
                      <Box
                        key={index}
                        sx={{
                          position: "absolute",
                          left: `${left}%`,
                          width: `${width}%`,
                          // Removed: height: "100%", // Allow height to be determined by content
                          bgcolor: "primary.light",
                          color: "primary.contrastText",
                          p: 1,
                          borderRadius: 1,
                          boxSizing: "border-box",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <Typography
                          variant="caption"
                          sx={{
                            overflowWrap: "break-word",
                            textAlign: "center",
                            lineHeight: 1.2,
                          }}
                        >
                          {s.job} ({s.start}-{s.end})
                        </Typography>
                      </Box>
                    );
                  })}
              </Box>
            </Box>
          ))}
        </Paper>
      </Box>
    );
  };

  // -----------------------------------------------------------------
  // STEP 1 – POLISHED UI
  // -----------------------------------------------------------------
  const Step1Content = () => (
    <Box sx={{ display: "flex", gap: 4, alignItems: "flex-start" }}>
      {/* LEFT – Form + Job list */}
      <Box sx={{ flex: 4 }}>
        <Alert
          severity="info"
          icon={<Schedule />}
          sx={{ mb: 3, borderRadius: 2, boxShadow: 1 }}
        >
          Define jobs with duration and machine. Each job becomes a{" "}
          <strong>qubit</strong> in the quantum circuit.
        </Alert>

        {/* ==== Add Job Card ==== */}
        {/* ==== Add Job Card ==== */}
        <Card
          raised
          sx={{
            mb: 4,
            borderRadius: 3,
            overflow: "hidden",
            background: `linear-gradient(135deg, ${alpha(
              theme.palette.primary.light,
              0.12
            )}, ${theme.palette.background.paper})`,
          }}
        >
          <CardContent sx={{ pb: 2 }}>
            <Typography
              variant="h6"
              gutterBottom
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 1,
                fontWeight: 500,
              }}
            >
              Add New Job
            </Typography>

            <Grid container spacing={2} alignItems="center">
              {/* ----- Job Name: larger dropdown + custom input inline ----- */}
              <Grid item xs={12} sm={7}>
                <FormControl
                  fullWidth
                  size="small"
                  sx={{ minWidth: { sm: 360 } }}
                >
                  <InputLabel>Job Name</InputLabel>
                  <Select
                    value={newName}
                    label="Job Name"
                    onChange={(e) => {
                      const val = e.target.value;
                      if (val !== "other") {
                        setNewName(val);
                      } else {
                        setNewName(""); // open for custom input
                      }
                    }}
                    sx={{ borderRadius: 2 }}
                    MenuProps={{
                      PaperProps: { sx: { maxHeight: 320, minWidth: 360 } },
                    }}
                  >
                    {suggestedJobNames.map((name) => (
                      <MenuItem key={name} value={name}>
                        {name}
                      </MenuItem>
                    ))}
                    <Divider sx={{ my: 0.5 }} />
                    <MenuItem value="other">
                      <em>+ Add Custom Job...</em>
                    </MenuItem>
                  </Select>

                  {/* Custom Input – appears only when "Other" is selected */}
                  {newName === "" && (
                    <Fade in>
                      <TextField
                        autoFocus
                        placeholder="Enter custom job name"
                        value={newName}
                        onChange={(e) => setNewName(e.target.value)}
                        fullWidth
                        variant="outlined"
                        size="small"
                        inputProps={{ maxLength: 50 }}
                        sx={{
                          mt: 1,
                          "& .MuiOutlinedInput-root": { borderRadius: 2 },
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") addJob();
                        }}
                      />
                    </Fade>
                  )}
                </FormControl>
              </Grid>

              {/* ----- Duration ----- */}
              <Grid item xs={6} sm={2}>
                <TextField
                  label="Duration"
                  type="number"
                  value={newDuration}
                  onChange={(e) =>
                    setNewDuration(Math.max(1, Number(e.target.value)))
                  }
                  inputProps={{ min: 1 }}
                  fullWidth
                  variant="outlined"
                  size="small"
                />
              </Grid>

              {/* ----- Machine ----- */}
              <Grid item xs={6} sm={2}>
                <FormControl fullWidth size="small">
                  <InputLabel>Machine</InputLabel>
                  <Select
                    value={newMachine}
                    label="Machine"
                    onChange={(e) => setNewMachine(e.target.value)}
                    sx={{ borderRadius: 2 }}
                    MenuProps={{ PaperProps: { sx: { minWidth: 160 } } }}
                  >
                    {machines.map((m) => (
                      <MenuItem key={m} value={m}>
                        {m}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              {/* ----- Add Button ----- */}
              <Grid item xs={12} sm={1} sx={{ display: "flex" }}>
                <Button
                  variant="contained"
                  startIcon={<AddIcon />}
                  onClick={addJob}
                  fullWidth
                  disabled={!newName.trim() || newDuration < 1}
                  sx={{ height: 40, fontWeight: 600, borderRadius: 2 }}
                >
                  Add
                </Button>
              </Grid>
            </Grid>
          </CardContent>
        </Card>

        {/* ==== Current Jobs ==== */}
        <Typography
          variant="h6"
          gutterBottom
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            fontWeight: 500,
            mb: 2,
          }}
        >
          <Memory color="primary" /> Current Jobs ({jobs.length})
        </Typography>

        <Grid container spacing={2}>
          {jobs.map((job) => (
            <Grid item xs={12} sm={6} md={4} key={job.id}>
              <Zoom in>
                <Card
                  raised
                  sx={{
                    height: "100%",

                    transition: "all 0.2s ease",
                    "&:hover": {
                      transform: "translateY(-4px)",
                      boxShadow: 6,
                    },
                    borderRadius: 2,
                    overflow: "hidden",
                    position: "relative",
                    background: `linear-gradient(135deg, ${alpha(
                      theme.palette.secondary.light,
                      0.08
                    )}, ${theme.palette.background.paper})`,
                  }}
                >
                  <CardContent sx={{ pb: 1 }}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                      }}
                    >
                      <Typography
                        variant="subtitle1"
                        color="primary"
                        sx={{ fontWeight: 600 }}
                      >
                        {job.name}
                      </Typography>
                      <Box>
                        <IconButton
                          size="small"
                          color="error"
                          onClick={() => deleteJob(job.id)}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </Box>

                    <Box sx={{ mt: 1 }}>
                      <Typography variant="body2">
                        <strong>Duration:</strong> {job.duration} unit
                        {job.duration > 1 ? "s" : ""}
                      </Typography>
                      <Typography variant="body2" component="div">
                        <strong>Machine:</strong>{" "}
                        <Chip
                          label={job.machine}
                          size="small"
                          sx={{
                            ml: 0.5,
                            bgcolor: (theme) =>
                              alpha(theme.palette.secondary.light, 0.4),
                          }}
                        />
                      </Typography>
                      {/*
                       */}
                    </Box>
                  </CardContent>
                </Card>
              </Zoom>
            </Grid>
          ))}
        </Grid>

        {/* ==== Proceed button ==== */}
        <Box textAlign="center" mt={5}>
          <Button
            variant="contained"
            color="success"
            size="large"
            startIcon={<PlayArrow />}
            onClick={() => setStep(2)}
            disabled={jobs.length === 0}
            sx={{
              px: 6,
              py: 1.8,
              fontSize: ".8rem",
              fontWeight: 500,
              borderRadius: 3,
              boxShadow: `0 8px 20px ${alpha(theme.palette.success.main, 0.3)}`,
              "&:hover": { transform: "translateY(-2px)" },
              transition: "all 0.3s ease",
            }}
          >
            Proceed to Quantum Solver
          </Button>
        </Box>
      </Box>

      {/* RIGHT – Quantum Mapping */}
      <Box
        sx={{
          flex: 1,
          pl: 4,
          borderLeft: `2px dashed ${alpha(theme.palette.divider, 0.5)}`,
          position: "sticky",
          top: theme.spacing(4),
        }}
      >
        <QuantumMappingPanel />
      </Box>
    </Box>
  );

  // -----------------------------------------------------------------
  // STEP 2 – unchanged (kept for completeness)
  // -----------------------------------------------------------------
  const Step2Content = () => (
    <Box sx={{ display: "flex", gap: 4, alignItems: "flex-start" }}>
      {/* LEFT – Constraints */}
      <Box sx={{ flex: 2 }}>
        <Alert severity="info" icon={<WarningAmber />} sx={{ mb: 3 }}>
          <strong>Step 2: Define Constraints</strong>
          <br />
          Now, let's set the rules for the schedule. Each rule you add modifies
          the problem's Hamiltonian, which is a mathematical representation of
          the total "energy" or "cost" of the schedule. The VQE algorithm will
          try to find a schedule that minimizes this energy.
        </Alert>

        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Global Constraints
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              These rules apply to all jobs. For example, preventing jobs from
              running at the same time on the same machine.
            </Typography>
            <ToggleButtonGroup
              orientation="vertical"
              value={activeConstraints}
              onChange={handleConstraintChange}
              sx={{ gap: 1.5, width: "100%" }}
            >
              {constraintOptions.map((c) => (
                <ToggleButton
                  key={c.id}
                  value={c.id}
                  sx={{
                    py: 1.8,
                    justifyContent: "flex-start",
                    borderRadius: 2,
                    textTransform: "none",
                    fontWeight: 500,
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1.5,
                      width: "100%",
                    }}
                  >
                    <CheckCircle
                      sx={{
                        opacity: activeConstraints.includes(c.id) ? 1 : 0.4,
                        fontSize: 20,
                      }}
                    />
                    <Box>
                      <Typography>{c.label}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        (Penalty: +{c.penalty} energy per conflict)
                      </Typography>
                    </Box>
                  </Box>
                </ToggleButton>
              ))}
            </ToggleButtonGroup>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Job Dependencies
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Define the order of jobs. For example, "Job A must finish before
              Job B can start."
            </Typography>

            <Grid container spacing={2} alignItems="center">
              <Grid item xs={12} sm={5}>
                <FormControl fullWidth sx={{ minWidth: { sm: 280 } }}>
                  <InputLabel>Job</InputLabel>
                  <Select
                    value={dependency.firstJob}
                    label="Job"
                    onChange={(e) =>
                      setDependency({ ...dependency, firstJob: e.target.value })
                    }
                    MenuProps={{
                      PaperProps: { sx: { maxHeight: 320, minWidth: 260 } },
                    }}
                  >
                    {jobs.map((j) => (
                      <MenuItem key={j.id} value={j.id}>
                        {j.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={2} sx={{ textAlign: "center" }}>
                <Typography>must run before</Typography>
              </Grid>
              <Grid item xs={12} sm={5}>
                <FormControl fullWidth sx={{ minWidth: { sm: 280 } }}>
                  <InputLabel>Job</InputLabel>
                  <Select
                    value={dependency.secondJob}
                    label="Job"
                    onChange={(e) =>
                      setDependency({
                        ...dependency,
                        secondJob: e.target.value,
                      })
                    }
                    MenuProps={{
                      PaperProps: { sx: { maxHeight: 320, minWidth: 260 } },
                    }}
                  >
                    {jobs.map((j) => (
                      <MenuItem
                        key={j.id}
                        value={j.id}
                        disabled={dependency.firstJob === j.id}
                      >
                        {j.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            </Grid>
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={addDependency}
              disabled={!dependency.firstJob || !dependency.secondJob}
              sx={{ mt: 2, width: "100%" }}
            >
              Add Dependency
            </Button>

            {/* Display Dependencies */}
            <Box sx={{ mt: 3 }}>
              {jobs.some((j) => j.dependencies.length > 0) ? (
                jobs.map(
                  (job) =>
                    job.dependencies.length > 0 && (
                      <Box key={job.id} sx={{ mb: 1 }}>
                        <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
                          <strong>{job.name}</strong> must start after:
                        </Typography>
                        <Paper
                          variant="outlined"
                          sx={{
                            p: 1,
                            display: "flex",
                            flexWrap: "wrap",
                            gap: 1,
                          }}
                        >
                          {job.dependencies.map((depId) => {
                            const depJob = jobs.find((j) => j.id === depId);
                            return (
                              <Chip
                                key={depId}
                                label={depJob ? depJob.name : "Unknown Job"}
                                size="small"
                                color="primary"
                                onDelete={() => {
                                  setJobs(
                                    jobs.map((j) =>
                                      j.id === job.id
                                        ? {
                                            ...j,
                                            dependencies: j.dependencies.filter(
                                              (d) => d !== depId
                                            ),
                                          }
                                        : j
                                    )
                                  );
                                  setDependencyConstraints((prev) =>
                                    prev.filter(
                                      (c) =>
                                        !(
                                          c.firstJobId === depId &&
                                          c.secondJobId === job.id
                                        )
                                    )
                                  );
                                }}
                              />
                            );
                          })}
                        </Paper>
                      </Box>
                    )
                )
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No dependencies defined yet.
                </Typography>
              )}
            </Box>
          </CardContent>
        </Card>

        <Box textAlign="center" mt={4}>
          <Button variant="outlined" onClick={() => setStep(1)} sx={{ mr: 2 }}>
            Back to Jobs
          </Button>
          <Button
            variant="contained"
            startIcon={<AutoFixHigh />}
            size="large"
            onClick={runTopologicalSort}
            sx={{
              px: 5,
              py: 1.5,
              fontWeight: 600,
              background: `linear-gradient(45deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
              "&:hover": { transform: "translateY(-2px)" },
            }}
          >
            Run VQE
          </Button>
        </Box>
      </Box>

      {/* RIGHT – Mapping + Status */}
      <Box
        sx={{
          flex: 1,
          pl: 4,
          borderLeft: `2px dashed ${alpha(theme.palette.divider, 0.5)}`,
        }}
      >
        <QuantumMappingPanel />
        <QuantumStatusPanel />
        {schedule.length > 0 && (
          <ScheduleTimeline schedule={schedule} jobs={jobs} />
        )}
      </Box>
    </Box>
  );

  // -----------------------------------------------------------------
  // MAIN RENDER
  // -----------------------------------------------------------------
  return (
    <Container maxWidth="xl" disableGutters sx={{ py: { xs: 2, md: 6 } }}>
      {/* Title */}
      <Zoom in>
        <Typography
          variant="h4"
          component="h1"
          align="center"
          gutterBottom
          sx={{
            fontWeight: 800,
            background: `linear-gradient(90deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
            backgroundClip: "text",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            mb: 3,
          }}
        >
          Job Scheduling Simulation
        </Typography>
      </Zoom>

      <Stepper activeStep={step - 1} alternativeLabel sx={{ mb: 5 }}>
        <Step>
          <StepLabel
            StepIconProps={{
              sx: { color: step === 1 ? "primary.main" : "success.main" },
            }}
          >
            Define Jobs
          </StepLabel>
        </Step>
        <Step>
          <StepLabel
            StepIconProps={{
              sx: { color: step === 2 ? "primary.main" : "inherit" },
            }}
          >
            Constraints
          </StepLabel>
        </Step>
      </Stepper>

      {/* STEP 1 */}
      <Fade in={step === 1} timeout={600}>
        <Box sx={{ display: step === 1 ? "block" : "none" }}>
          {Step1Content()}
        </Box>
      </Fade>

      {/* STEP 2 */}
      <Fade in={step === 2} timeout={600}>
        <Box sx={{ display: step === 2 ? "block" : "none" }}>
          {Step2Content()}
        </Box>
      </Fade>
    </Container>
  );
};

export default Simulation;
