// src/components/JobDefinition.jsx
import React from "react";
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Alert,
} from "@mui/material";
import { Add, ArrowForward } from "@mui/icons-material";

const JobDefinition = ({
  jobs,
  newName,
  setNewName,
  newDuration,
  setNewDuration,
  newMachine,
  setNewMachine,
  machines,
  addJob,
  onNext,
}) => {
  return (
    <Box>
      <Alert severity="info" sx={{ mb: 3 }}>
        Start by defining the jobs to be scheduled. Add jobs and specify their duration and required machine.
      </Alert>
      <Grid container spacing={4}>
        <Grid item xs={12} lg={8}>
          <Typography variant="h5" gutterBottom>Current Jobs</Typography>
          <Grid container spacing={2}>
            {jobs.map((job) => (
              <Grid item key={job.id} xs={12} md={6}>
                <Card>
                  <CardContent>
                    <Typography variant="h6">{job.name}</Typography>
                    <Typography>Duration: {job.duration} units</Typography>
                    <Typography>Machine: {job.machine}</Typography>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Grid>
        <Grid item xs={12} lg={4}>
          <Typography variant="h5" gutterBottom>Add New Job</Typography>
          <Box component="form" noValidate autoComplete="off">
            <FormControl fullWidth sx={{ mb: 2 }}>
              <TextField
                label="Job Name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                variant="outlined"
              />
            </FormControl>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <TextField
                label="Duration (units)"
                type="number"
                value={newDuration}
                onChange={(e) => setNewDuration(Number(e.target.value))}
                inputProps={{ min: 1 }}
                variant="outlined"
              />
            </FormControl>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Machine</InputLabel>
              <Select
                value={newMachine}
                label="Machine"
                onChange={(e) => setNewMachine(e.target.value)}
              >
                {machines.map((m) => (
                  <MenuItem key={m} value={m}>
                    {m}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Button
              variant="contained"
              startIcon={<Add />}
              onClick={addJob}
              fullWidth
            >
              Add Job
            </Button>
          </Box>
        </Grid>
      </Grid>
      <Box textAlign="center" mt={4}>
        <Button
          variant="contained"
          color="primary"
          size="large"
          endIcon={<ArrowForward />}
          onClick={onNext}
        >
          Proceed to Constraints
        </Button>
      </Box>
    </Box>
  );
};

export default JobDefinition;
