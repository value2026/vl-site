// src/LeftPanel/ParametersTable.jsx
import React from "react";
import {
  Box,
  Paper,
  Typography,
  alpha,
  useTheme,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import { Tune } from "@mui/icons-material";

const ParametersTable = ({ thetaHistory, theta }) => {
  const theme = useTheme();

  return (
    <Paper
      elevation={6}
      sx={{
        p: 3,
        borderRadius: 3,
        background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.05)} 0%, ${alpha(theme.palette.secondary.main, 0.03)} 100%)`,
        border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
      }}
    >
      <Box display="flex" alignItems="center" gap={1} mb={2}>
        <Tune sx={{ color: "primary.main" }} />
        <Typography variant="h6" fontWeight={700}>
          Parameter Evolution (θ)
        </Typography>
      </Box>
      <TableContainer sx={{ maxHeight: 520 }}>
        <Table stickyHeader size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ fontWeight: 700 }}>Iter</TableCell>
              {Object.keys(theta).slice(0, 6).map((key) => (
                <TableCell key={key} align="center" sx={{ fontWeight: 700 }}>
                  θ{key}
                </TableCell>
              ))}
              {Object.keys(theta).length > 6 && <TableCell>...</TableCell>}
            </TableRow>
          </TableHead>
          <TableBody>
            {thetaHistory.slice(-10).reverse().map((row, idx) => (
              <TableRow key={idx}>
                <TableCell>{thetaHistory.length - idx}</TableCell>
                {Object.values(row).slice(0, 6).map((val, i) => (
                  <TableCell key={i} align="center">
                    {val.toFixed(4)}
                  </TableCell>
                ))}
                {Object.keys(theta).length > 6 && <TableCell>...</TableCell>}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default ParametersTable;