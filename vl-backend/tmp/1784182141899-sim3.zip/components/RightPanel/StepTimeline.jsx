import React, { useRef, useEffect } from "react";
import { useSelector } from "react-redux";
import {
  Box,
  Paper,
  Typography,
  Chip,
  Stack,
  Tooltip,
  useTheme,
  alpha,
  Fade,
  Grid,
  Alert, // Added Alert import
} from "@mui/material";

import EnergyGraph from "./EnergyGraph";
import SchedulePanel from "./SchedulePanel";
import QuantumMappingPanel from "./QuantumMappingPanel";
import QuantumStatusPanel from "./QuantumStatusPanel";
import AnsatzCircuitPanel from "./AnsatzCircuitPanel";

/* --------------------------------------------------------------- */
/*  Main Timeline                                                  */
/* --------------------------------------------------------------- */
const StepTimeline = () => {
  const { step, energyHistory, optimizationStarted } = useSelector((state) => state.simulation);
  const containerRef = useRef(null);
  const stepRefs = { 1: useRef(null), 2: useRef(null), 3: useRef(null), 4: useRef(null) };

  useEffect(() => {
    const ref = stepRefs[step];
    if (ref?.current && containerRef.current) {
      ref.current.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [step]);

  return (
    <Box
      ref={containerRef}
      sx={{
        height: "100%",
        maxHeight: "100vh",
        overflowY: "auto",
        p: { xs: 2, lg: 3 },
        bgcolor: "background.default",
        "&::-webkit-scrollbar": { width: 8 },
        "&::-webkit-scrollbar-thumb": { bgcolor: "grey.400", borderRadius: 4 },
      }}
    >
      <Stack
        direction="row"
        justifyContent="center"
        spacing={2}
        sx={{
          position: "sticky",
          top: 0,
          bgcolor: "background.default",
          zIndex: 10,
          py: 1,
          borderBottom: `1px solid ${alpha("#000", 0.1)}`,
        }}
      >
        {[1, 2, 3, 4].map((s) => (
          <Tooltip key={s} title={`Step ${s}`} arrow>
            <Chip
              label={s}
              color={step >= s ? "primary" : "default"}
              variant={step === s ? "filled" : "outlined"}
              sx={{
                width: 48,
                height: 48,
                fontSize: "1.1rem",
                fontWeight: 700,
                borderRadius: "50%",
              }}
            />
          </Tooltip>
        ))}
      </Stack>

      <Stack spacing={4} mt={2}>
        {step >= 1 && <div ref={stepRefs[1]}><QuantumMappingPanel /></div>}
        {step >= 2 && <div ref={stepRefs[2]}><QuantumStatusPanel /></div>}
        {step >= 3 && <div ref={stepRefs[3]}><AnsatzCircuitPanel /></div>}
        {step >= 4 && (
          <div ref={stepRefs[4]}>
            <Fade in timeout={600}>
              <Paper
                elevation={6}
                sx={{
                  p: 4,
                  borderRadius: 4,
                  border: `2px solid ${alpha("#10b981", 0.3)}`,
                  background: `linear-gradient(135deg, ${alpha("#10b981", 0.04)} 0%, ${alpha("#6366f1", 0.03)} 100%)`,
                  boxShadow: "0 8px 32px rgba(16, 185, 129, 0.15)",
                }}
              >
                <Box textAlign="center" py={4}>
                  <Typography variant="h6" color="text.secondary">
                    Step 4: VQE Optimization
                  </Typography>
                  <Alert severity="info" sx={{ mt: 2, borderRadius: 3, fontSize: "0.875rem", textAlign: "left" }}>
                    <strong>Classical Optimizer:</strong> Iteratively updates the quantum circuit parameters (θ) to minimize the energy function, guiding the VQE algorithm towards the optimal solution.
                  </Alert>
                </Box>
                {optimizationStarted && (
                  <>
                    <Grid container spacing={4} mb={4}>
                      <Grid item xs={12} lg={8}>
                        <EnergyGraph />
                      </Grid>
                      
                    </Grid>
                    <SchedulePanel />
                  </>
                )}
              </Paper>
            </Fade>
          </div>
        )}
      </Stack>
    </Box>
  );
};

export default StepTimeline;