// src/components/RightPanel/AnsatzCircuitPanel.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import {
    Box,
    Paper,
    Typography,
    alpha,
    Zoom,
} from "@mui/material";
import { useQuantumEnergy } from '../../hooks/useQuantumEnergy';

const AnsatzCircuitPanel = () => {
    const { jobs, dependencyConstraints, theta } = useSelector((state) => state.simulation);
    const quantumEnergy = useQuantumEnergy();

    const HTerms = dependencyConstraints?.map(d => {
        const i = jobs.findIndex(j => j.id === d.firstJobId);
        const j = jobs.findIndex(j => j.id === d.secondJobId);
        const c = d.penalty || 5;
        return { coeff: c, i, j };
    }) || [];

    const hasTheta = Object.keys(theta).length > 0;
    const hasH = HTerms.length > 0;

    return (
        <Zoom in timeout={700}>
            <Paper
                elevation={0}
                sx={{
                    p: 4,
                    borderRadius: 3,
                    border: `1px solid ${alpha("#ddd", 0.6)}`,
                    bgcolor: "background.paper",
                }}
            >
                {/* STEP 3 HEADING — CLEAR AND BOLD */}
                <Box display="flex" alignItems="center" gap={2} mb={4}>
                    <Box
                        sx={{
                            bgcolor: "#5b21b6",
                            color: "white",
                            width: 40,
                            height: 40,
                            borderRadius: "50%",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontWeight: "bold",
                            fontSize: "1.1rem",
                        }}
                    >
                        3
                    </Box>
                    <Typography variant="h6" fontWeight={700} color="text.primary">
                        Step 3: Run the Quantum Ansatz Circuit
                    </Typography>
                </Box>

                {/* Friendly Intro Box */}
                <Paper
                    variant="outlined"
                    sx={{
                        p: 3,
                        mb: 4,
                        bgcolor: alpha("#e0f2fe", 0.4),
                        borderColor: alpha("#0ea5e9", 0.3),
                    }}
                >
                    <Typography variant="body1" sx={{ fontSize: "0.95rem", lineHeight: 1.7 }}>
                        <strong>What is happening here?</strong>
                        <br />
                        Each job gets its own qubit. We apply a rotation gate Rx(θᵢ) — the angle θᵢ controls <em>when</em> the job should run.
                        <br />
                        The quantum computer adjusts these angles to find the best possible schedule that respects all dependencies.
                    </Typography>
                </Paper>

                {/* Clean Quantum Math */}
                <Paper variant="outlined" sx={{ p: 3.5, borderRadius: 2, bgcolor: "#fafafa", textAlign: "center", fontFamily: "monospace" }}>
                    <Typography sx={{ fontSize: "1.35rem", fontWeight: 600, color: "#5b21b6", mb: 2 }}>
                        ⟨ψ(θ) | H | ψ(θ)⟩
                    </Typography>

                    {hasTheta && (
                        <Typography fontSize="0.92rem" color="text.secondary" sx={{ mb: 1.2 }}>
                            θ = ({Object.entries(theta).map(([i, v]) => `θ${i}=${Number(v).toFixed(3)}`).join(", ")})
                        </Typography>
                    )}

                    {hasH && (
                        <Typography fontSize="0.92rem" color="text.secondary" sx={{ mb: 2 }}>
                            H ={" "}
                            {HTerms.map((t, i) => (
                                <React.Fragment key={i}>
                                    {i > 0 && " "}
                                    +{t.coeff} Z{t.i}Z{t.j}
                                </React.Fragment>
                            ))}
                        </Typography>
                    )}

                    {quantumEnergy && (
                        <>
                            <Typography fontSize="0.88rem" color="text.secondary">
                                current energy →
                            </Typography>
                            <Typography fontSize="1.7rem" fontWeight="bold" color={quantumEnergy.value < 0 ? "#166534" : "#dc2626"}>
                                {Number(quantumEnergy.value).toFixed(6)}
                            </Typography>
                            <Typography fontSize="0.82rem" color="text.secondary" sx={{ mt: 0.5 }}>
                                lower or negative = better schedule
                            </Typography>
                        </>
                    )}
                </Paper>
            </Paper>
        </Zoom>
    );
};

export default AnsatzCircuitPanel;