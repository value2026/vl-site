// src/components/RightPanel/SchedulePanel.jsx
import React from "react";
import { useSelector } from "react-redux";
import {
  Box,
  Paper,
  Typography,
  alpha,
  useTheme,
  Grid,
  Chip,
  Stack,
} from "@mui/material";
import { Event, Science, Timeline } from "@mui/icons-material";
import { motion } from "framer-motion";

const SchedulePanel = () => {
  const { schedule, jobs, machines } = useSelector((state) => state.simulation);
  const theme = useTheme();

  const maxTime = Math.max(
    10,
    ...(schedule || []).map((s) => s.endTime)
  );
  const colors = [
    "#6366f1",
    "#8b5cf6",
    "#ec4899",
    "#f59e0b",
    "#10b981",
    "#06b6d4",
  ];
  const jobMap = Object.fromEntries(jobs.map((j) => [j.name, j]));

  return (
    <Paper
      elevation={6}
      sx={{
        p: 2,
        borderRadius: 4,
        background: `linear-gradient(135deg, ${alpha(
          "#10b981",
          0.05
        )} 0%, ${alpha("#6366f1", 0.03)} 100%)`,
        border: `2px solid ${alpha("#10b981", 0.3)}`,
      }}
    >
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        mb={1.5}
      >
        <Stack direction="row" alignItems="center" spacing={1}>
          <Timeline sx={{ fontSize: 20, color: "success.main" }} />
          <Typography variant="h6" fontWeight={800}>
            Final Quantum Schedule
          </Typography>
        </Stack>
        <Chip
          icon={<Science />}
          label={`Makespan: ${maxTime}h`}
          color="success"
          variant="outlined"
          size="small"
          sx={{ fontWeight: 600 }}
        />
      </Stack>

      {schedule.length > 0 ? (
        <Box sx={{ overflowX: "auto", p: 1 }}>
          <Box sx={{ minWidth: 600 }}>
            {/* TIME HEADER */}
            <Box
              sx={{
                display: "flex",
                mb: 0.5,
                color: "text.secondary",
                fontSize: "0.75rem",
                fontWeight: 600,
              }}
            >
              <Box sx={{ width: 90 }} />
              {Array.from({ length: Math.ceil(maxTime) + 1 }, (_, i) => (
                <Box key={i} sx={{ width: 40, textAlign: "center" }}>
                  {i}
                </Box>
              ))}
            </Box>

            {/* MACHINES */}
            {machines.map((m) => (
              <Box
                key={m}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  mb: 1.5,
                  position: "relative",
                }}
              >
                <Box sx={{ width: 90, pr: 1, textAlign: "right" }}>
                  <Chip
                    label={m}
                    size="small"
                    variant="outlined"
                    sx={{
                      fontSize: "0.65rem",
                      fontWeight: 600,
                      borderColor: "success.light",
                      color: "success.dark",
                    }}
                  />
                </Box>

                <Box sx={{ flex: 1, position: "relative", height: 32 }}>
                  {/* HORIZONTAL LINE */}
                  <Box
                    sx={{
                      position: "absolute",
                      left: 0,
                      top: "50%",
                      width: `${Math.ceil(maxTime) * 40}px`,
                      height: "2px",
                      bgcolor: alpha(theme.palette.success.main, 0.2),
                      zIndex: 1,
                    }}
                  />

                  {/* VERTICAL LINES */}
                  {Array.from(
                    { length: Math.ceil(maxTime) + 1 },
                    (_, i) => (
                      <Box
                        key={`v-${i}`}
                        sx={{
                          position: "absolute",
                          left: `${i * 40}px`,
                          top: 0,
                          width: "1px",
                          height: "100%",
                          bgcolor: alpha(theme.palette.success.main, 0.2),
                          zIndex: 1,
                        }}
                      />
                    )
                  )}

                  {/* JOBS */}
                  <Box sx={{ position: "relative", zIndex: 10 }}>
                    {schedule.map((item, idx) => {
                      const job = jobMap[item.job];
                      if (!job || item.machine !== m) return null;
                      const jobDuration = item.endTime - item.startTime;
                      return (
                        <motion.div
                          key={idx}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{
                            type: "spring",
                            stiffness: 400,
                            damping: 25,
                          }}
                          title={`${job.name}: ${item.startTime}h - ${item.endTime}h`}
                          style={{
                            position: "absolute",
                            left: `${item.startTime * 40}px`,
                            top: 4,
                            width: `${jobDuration * 40 - 4}px`,
                            height: 24,
                            background: `linear-gradient(45deg, ${
                              colors[job.id % colors.length]
                            }, ${alpha(colors[job.id % colors.length], 0.7)})`,
                            borderRadius: 6,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            color: "white",
                            fontSize: 11,
                            fontWeight: 700,
                            boxShadow:
                              "0 4px 12px rgba(0,0,0,0.2)",
                            border: "1px solid rgba(255,255,255,0.4)",
                            cursor: "pointer",
                          }}
                        >
                          {job.name}
                        </motion.div>
                      );
                    })}
                  </Box>
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
      ) : (
        <Box textAlign="center" py={5}>
          <Typography variant="subtitle1" color="text.secondary">
            Start optimization to see the quantum result!
          </Typography>
        </Box>
      )}
    </Paper>
  );
};

export default SchedulePanel;