// src/components/RightPanel/QuantumStatusPanel.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import {
    Box,
    Paper,
    Typography,
    Chip,
    Stack,
    useTheme,
    alpha,
    Zoom,
} from "@mui/material";
import {
    Memory,
} from "@mui/icons-material";
import { selectHamiltonian } from '../../redux/simulationSlice';

const QuantumStatusPanel = () => {
    const { jobs, dependencyConstraints } = useSelector((state) => state.simulation);
    const hamiltonian = useSelector(selectHamiltonian);
    const theme = useTheme();

    const constraints = dependencyConstraints?.map((d) => ({
        jobA: jobs.find(j => j.id === d.firstJobId)?.name || "Job A",
        jobB: jobs.find(j => j.id === d.secondJobId)?.name || "Job B",
        penalty: d.penalty || 5,
    })) || [];

    const hasConstraints = constraints.length > 0;

    return (
        <Zoom in timeout={700}>
            <Paper
                elevation={0}
                sx={{
                    p: 4,
                    borderRadius: 3,
                    border: `1px solid ${alpha(theme.palette.divider, 0.8)}`,
                    bgcolor: "background.paper",
                    boxShadow: "none",
                }}
            >
                {/* Clean Header */}
                <Box display="flex" alignItems="center" gap={2} mb={4}>
                    <Memory sx={{ fontSize: 30, color: "text.secondary" }} />
                    <Box>
                        <Typography variant="h6" fontWeight={600} color="text.primary">
                            Step 2: Constraint Encoding
                        </Typography>
                    </Box>
                </Box>

                <Paper
                    variant="outlined"
                    sx={{
                        p: 3,
                        mb: 4,
                        borderRadius: 2,
                        borderColor: alpha("#6366f1", 0.3),
                        bgcolor: alpha("#eef2ff", 0.4),
                    }}
                >
                    <Typography variant="body1" color="text.primary" sx={{ lineHeight: 1.75, fontSize: "0.95rem" }}>
                        In quantum optimization, we don’t “solve” constraints directly.
                        <br />
                        Instead, we <strong>turn each scheduling rule into a penalty term</strong> in the quantum Hamiltonian H.
                    </Typography>
                    <Box sx={{ mt: 2, pl: 0.5 }}>
                        <Typography variant="body2" color="success.main" fontWeight={500}>
                            Follow all rules → low energy
                        </Typography>
                        <Typography variant="body2" color="error.main" fontWeight={500}>
                            Violate a rule → high energy
                        </Typography>
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 2, fontStyle: "italic" }}>
                        The quantum computer naturally evolves toward the lowest-energy state — the optimal valid schedule.
                    </Typography>
                </Paper>

                <Paper
                    sx={{
                        p: 3,
                        mb: 4,
                        borderRadius: 2,
                        bgcolor: "#0f172a",
                        color: "#e2e8f0",
                        fontFamily: "monospace",
                        textAlign: "center",
                        border: `1px solid ${alpha("#475569", 0.6)}`,
                    }}
                >
                    <Typography variant="caption" sx={{ color: "#94a3b8", display: "block", mb: 2 }}>
                        Hamiltonian Penalty Terms
                    </Typography>

                    {hasConstraints ? (
                        <Box sx={{ mb: 2 }}>
                            {constraints.map((c, i) => {
                                const qubitA = jobs.findIndex(j => j.name === c.jobA);
                                const qubitB = jobs.findIndex(j => j.name === c.jobB);
                                return (
                                    <Typography key={i} variant="body1" fontWeight={500} sx={{ mb: 0.5 }}>
                                        +{c.penalty} Z<sub>{qubitA}</sub>Z<sub>{qubitB}</sub>
                                    </Typography>
                                );
                            })}
                        </Box>
                    ) : (
                        <Typography variant="body1" fontWeight={500}>
                            +c (I − Z<sub>i</sub>Z<sub>j</sub>)
                        </Typography>
                    )}

                    <Box sx={{ mt: 2.5, fontSize: "0.8rem", lineHeight: 1.6, color: "#94a3b8" }}>
                        <Typography variant="caption" component="div">
                            <strong>c</strong> = penalty weight (how important this rule is)
                        </Typography>
                        <Typography variant="caption" component="div">
                            <strong>I</strong> = identity operator
                        </Typography>
                        <Typography variant="caption" component="div">
                            <strong>ZᵢZⱼ</strong> = checks if job i finishes before job j
                        </Typography>
                        <Typography variant="caption" component="div" sx={{ mt: 0.5, fontStyle: "italic" }}>
                            +1 = correct order → no penalty<br />
                            −1 = wrong order → penalty = 2c
                        </Typography>
                    </Box>
                </Paper>
                {hasConstraints ? (
                    <Box>
                        <Typography variant="subtitle2" fontWeight={600} color="text.secondary" gutterBottom>
                            Active Constraints ({constraints.length})
                        </Typography>
                        <Stack spacing={1.5}>
                            {constraints.map((c, i) => (
                                <Box
                                    key={i}
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        gap: 2,
                                        p: 2,
                                        borderRadius: 2,
                                        bgcolor: alpha("#f8fafc", 0.6),
                                        border: `1px solid ${alpha("#e2e8f0", 0.7)}`,
                                    }}
                                >
                                    <Typography variant="body2" fontWeight={500}>{c.jobA}</Typography>
                                    <Typography variant="body2" color="text.secondary">before</Typography>
                                    <Typography variant="body2" fontWeight={500}>{c.jobB}</Typography>
                                    <Box sx={{ ml: "auto" }}>
                                        <Chip label={`+${c.penalty}`} size="small" sx={{ bgcolor: alpha("#ef4444", 0.12), color: "#dc2626", fontWeight: 600 }} />
                                    </Box>
                                </Box>
                            ))}
                        </Stack>
                    </Box>
                ) : (
                    <Paper sx={{ p: 4, textAlign: "center", borderRadius: 2, border: `1px dashed ${alpha("#94a3b8", 0.4)}`, bgcolor: alpha("#f8fafc", 0.3) }}>
                        <Typography variant="body2" color="text.secondary">
                            No dependency constraints defined yet
                        </Typography>
                    </Paper>
                )}

                {hasConstraints && (
                    <Box sx={{ mt: 5 }}>
                        <Typography variant="subtitle2" fontWeight={600} color="text.secondary" gutterBottom>
                            Final Hamiltonian H (penalty terms)
                        </Typography>
                        <Paper
                            sx={{
                                p: 3,
                                borderRadius: 2,
                                bgcolor: "#0f172a",
                                color: "#e0f2fe",
                                fontFamily: "monospace",
                                fontSize: "1rem",
                                lineHeight: 2,
                                border: `1px solid ${alpha("#475569", 0.6)}`,
                                overflowX: "auto",
                            }}
                        >
                            <Typography variant="body1" component="div" sx={{ textAlign: "center" }}>
                                H ={" "}
                                {constraints.map((c, i) => {
                                    const qA = jobs.findIndex(j => j.name === c.jobA);
                                    const qB = jobs.findIndex(j => j.name === c.jobB);
                                    return (
                                        <span key={i}>
                                            {i > 0 && "  +  "}
                                            <strong>+{c.penalty}</strong> Z<sub>{qA}</sub>Z<sub>{qB}</sub>
                                        </span>
                                    );
                                })}
                            </Typography>
                        </Paper>

                    </Box>
                )}

                <Box sx={{ mt: 4, textAlign: "center" }}>
                    <Typography variant="caption" color="text.secondary">
                        Lower total energy = better constraint satisfaction
                    </Typography>
                </Box>
            </Paper>
        </Zoom>
    );
};

export default QuantumStatusPanel;