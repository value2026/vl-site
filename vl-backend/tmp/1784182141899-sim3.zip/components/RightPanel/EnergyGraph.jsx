import React from "react";
import { useSelector } from "react-redux";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Label,
} from "recharts";
import {
  Paper,
  Typography,
  Box,
  Stack,
  Chip,
 
} from "@mui/material";
import { TrendingDown } from "@mui/icons-material"; // ← Add if missing
const EnergyGraph = () => {
  const { energyHistory } = useSelector((state) => state.simulation);
  const data = energyHistory.map((energy, index) => ({
    iteration: index + 1,
    energy,
  }));

  const minEnergy = Math.min(...energyHistory);
  const isDownward = energyHistory.length > 1 && energyHistory[energyHistory.length - 1] < energyHistory[0] * 0.8;

  return (
    <Paper elevation={6} sx={{ p: 3, borderRadius: 3 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
        <Typography variant="h6" fontWeight={700} color="primary">
          VQE Optimization Progress
        </Typography>
        {isDownward && (
          <Chip
            icon={<TrendingDown />}
            label="Energy Dropping!"
            color="success"
            size="small"
            sx={{ fontWeight: 600 }}
          />
        )}
      </Stack>

      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 40 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="iteration">
            <Label value="Iteration" offset={-10} position="insideBottom" />
          </XAxis>
          <YAxis>
            <Label value="Energy ⟨ψ|H|ψ⟩" angle={-90} position="insideLeft" />
          </YAxis>
          <Tooltip
            contentStyle={{ borderRadius: 8, border: "none", boxShadow: 2 }}
            formatter={(value) => value.toFixed(6)}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="energy"
            stroke="#6366f1"
            strokeWidth={3}
            dot={{ fill: "#6366f1", r: 5 }}
            activeDot={{ r: 8 }}
          />
        </LineChart>
      </ResponsiveContainer>

      <Box mt={2} p={2} bgcolor="#f8f9fa" borderRadius={2} borderLeft={`4px solid #6366f1`}>
        <Typography variant="body2" fontWeight={600} color="primary">
          Final Energy: {isFinite(minEnergy) ? minEnergy.toFixed(6) : 'N/A'}
        </Typography>
        <Typography variant="caption" color="text.secondary">
          {isDownward
            ? "VQE successfully minimized energy → optimal θ found!"
            : "Energy stable → schedule ready!"}
        </Typography>
      </Box>
    </Paper>
  );
};

export default EnergyGraph;