// src/components/RightPanel/QuantumMappingPanel.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import {
    Box,
    Paper,
    Typography,
    Chip,
    Stack,
    Divider,
    Grid,
    useTheme,
    alpha,
    Zoom,
} from "@mui/material";
import {
    Science,
} from "@mui/icons-material";

const QuantumMappingPanel = () => {
    const { jobs } = useSelector((state) => state.simulation);
    const theme = useTheme();

    return (
        <Paper
            elevation={3}
            sx={{
                p: 3,
                borderRadius: 3,
                border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
                background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.03)} 0%, transparent 100%)`,
            }}
        >
            <Stack direction="row" alignItems="center" gap={1} mb={3}>
                <Science color="primary" sx={{ fontSize: 32 }} />
                <Typography variant="h6" fontWeight={700}>
                    Qubit to Job Mapping
                </Typography>
            </Stack>

            {/* MAIN MAPPING LIST */}
            <Stack spacing={1.5} mb={4}>
                {jobs.map((j, i) => (
                    <Zoom in key={j.id} style={{ transitionDelay: `${i * 80}ms` }}>
                        <Stack direction="row" alignItems="center" spacing={2}>
                            <Chip label={`Q${i}`} color="primary" size="small" />
                            <Typography variant="body1" fontWeight={600}>{j.name}</Typography>
                            <Typography variant="body2" color="text.secondary">
                                ({j.duration}h on {j.machine})
                            </Typography>
                        </Stack>
                    </Zoom>
                ))}
            </Stack>

            {/* EXPLANATION CARD */}
            <Paper
                elevation={2}
                sx={{
                    p: 3,
                    borderRadius: 3,
                    bgcolor: alpha(theme.palette.info.main, 0.08),
                    border: `1px dashed ${alpha(theme.palette.info.main, 0.3)}`,
                }}
            >
                <Stack spacing={2.5}>
                    <Box>
                        <Typography variant="h6" fontWeight={700} color="info.main" gutterBottom>
                            1 Job = 1 Qubit
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                            We assign <strong>one qubit to each job</strong> to control its scheduling.
                        </Typography>
                    </Box>

                    <Divider />

                    <Grid container spacing={3}>
                        <Grid item xs={12} md={6}>
                            {/* You can leave empty if you want balance — or remove entirely */}
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <Box>
                                <Typography variant="subtitle2" fontWeight={600} gutterBottom>
                                    Why This Works
                                </Typography>
                                <Box sx={{ pl: 2 }}>
                                    <Typography variant="body2" color="text.secondary" component="div">
                                        <strong>Exponential Speedup:</strong> 10 jobs = 2¹⁰ = 1024 possible orders<br />
                                        <strong>Quantum explores all at once!</strong>
                                    </Typography>
                                </Box>
                            </Box>
                        </Grid>
                    </Grid>

                </Stack>
            </Paper>
        </Paper>
    );
};

export default QuantumMappingPanel;