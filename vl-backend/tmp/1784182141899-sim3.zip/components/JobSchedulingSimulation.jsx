import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Box,
  Paper,
  useTheme,
  useMediaQuery,
} from "@mui/material";

import Step1_DefineJobs from "./LeftPanel/Step1_DefineJobs";
import Step2_ConstraintsVQE from "./LeftPanel/Step2_ConstraintsVQE";
import Step3_ConstructAnsatz from "./LeftPanel/Step3_ConstructAnsatz";
import Step4_VQE_Optimization from "./LeftPanel/Step4_VQE_Optimization";
import StepTimeline from "./RightPanel/StepTimeline";
import { setEnergyHistory, setOptimizationStarted } from "../redux/simulationSlice";


// ─────────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────
const JobSchedulingSimulation = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("lg"));
  const dispatch = useDispatch();

  const {
    step,
    energy,
    energyHistory,
  } = useSelector((state) => state.simulation);

  // ── Update energy history
  useEffect(() => {
    if (energyHistory.length === 0 || energyHistory[energyHistory.length - 1] !== energy) {
      dispatch(setEnergyHistory([...energyHistory, energy]));
    }
  }, [energy, energyHistory, dispatch]);

  useEffect(() => {
    if (step !== 4) {
      dispatch(setOptimizationStarted(false));
    }
  }, [step, dispatch]);

  return (
    <Box sx={{ width: "100vw", minHeight: "100vh", bgcolor: "#f5f7fa", display: "flex", flexDirection: "column" }}>
      {/* HEADER */}
      
   
      {/* MAIN SPLIT LAYOUT */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: isMobile ? "column" : "row",
          width: "100%",
          height: "calc(100vh - 180px)",
          overflow: "hidden",
        }}
      >
        {/* LEFT PANEL */}
        <Box
          sx={{
            flex: isMobile ? "none" : 2,
            width: isMobile ? "100%" : "66.66%",
            height: isMobile ? "50%" : "100%",
            bgcolor: "#f8fafc",
            borderRight: isMobile ? "none" : `1px solid ${theme.palette.divider}`,
            overflowY: "auto",
          }}
        >
          <Paper elevation={0} sx={{ height: "100%", bgcolor: "transparent", p: { xs: 2, md: 3 } }}>
            {step === 1 && <Step1_DefineJobs />}
            {step === 2 && <Step2_ConstraintsVQE />}
            {step === 3 && <Step3_ConstructAnsatz />}
            {step === 4 && <Step4_VQE_Optimization />}
          </Paper>
        </Box>

        {/* RIGHT PANEL */}
        <Box
          sx={{
            flex: isMobile ? "none" : 1,
            width: isMobile ? "100%" : "33.33%",
            height: isMobile ? "50%" : "100%",
            bgcolor: "#fafafa",
            overflowY: "auto",
            p: { xs: 2, md: 3 },
          }}
        >
          <StepTimeline />
        </Box>
      </Box>
    </Box>
  );
};

export default JobSchedulingSimulation;