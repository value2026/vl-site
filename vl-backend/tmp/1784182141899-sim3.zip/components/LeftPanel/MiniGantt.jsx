// src/components/LeftPanel/MiniGantt.jsx
import React from 'react';
import {
    Box,
    Paper,
    Typography,
    Chip,
    Stack,
} from "@mui/material";
import {
    Timeline,
} from "@mui/icons-material";
import { motion } from "framer-motion";
import { useSelector } from 'react-redux';
import { selectPreviewSchedule } from '../../redux/simulationSlice';

const MiniGantt = ({ highlight = [] }) => {
    const { jobs, machines } = useSelector((state) => state.simulation);
    const schedule = useSelector(selectPreviewSchedule);

    const colors = ["#6366f1", "#8b5cf6", "#ec4899", "#f59e0b", "#10b981", "#06b6d4"];
    const jobMap = Object.fromEntries(jobs.map(j => [j.id, j]));
    const maxTime = Math.max(6, ...(schedule.map(s => s.start + s.duration) || [6]));

    return (
        <Paper
            elevation={8}
            sx={{
                p: 2,
                borderRadius: 3,
                border: "1px solid",
                borderColor: "divider",
                bgcolor: "background.paper",
                boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
            }}
        >
            <Stack direction="row" alignItems="center" spacing={1} mb={1.5}>
                <Timeline sx={{ fontSize: 20, color: "primary.main" }} />
                <Typography variant="subtitle2" fontWeight={600}>Live Schedule Preview (Not Optimized)</Typography>
            </Stack>

            <Box sx={{ overflowX: "auto" }}>
                <Box sx={{ minWidth: 500 }}>
                    {/* TIME HEADER */}
                    <Box sx={{ display: "flex", mb: 0.5, color: "text.secondary", fontSize: "0.75rem", fontWeight: 600 }}>
                        <Box sx={{ width: 80 }} />
                        {Array.from({ length: Math.ceil(maxTime) }, (_, i) => (
                            <Box key={i} sx={{ width: 40, textAlign: "center" }}>{i}</Box>
                        ))}
                    </Box>

                    {/* MACHINES */}
                    {machines.map((m) => (
                        <Box key={m} sx={{ display: "flex", alignItems: "center", mb: 1.5, position: "relative" }}>
                            <Box sx={{ width: 80, pr: 1, textAlign: "right" }}>
                                <Chip label={m} size="small" variant="outlined" sx={{ fontSize: "0.65rem", fontWeight: 600 }} />
                            </Box>

                            <Box sx={{ flex: 1, position: "relative", height: 32 }}>
                                {/* HORIZONTAL LINE */}
                                <Box
                                    sx={{
                                        position: "absolute",
                                        left: 0,
                                        top: 0,
                                        width: `${Math.ceil(maxTime) * 40}px`,
                                        height: "1px",
                                        bgcolor: "#c7d2fe",
                                        zIndex: 1,
                                    }}
                                />

                                {/* VERTICAL LINES */}
                                {Array.from({ length: Math.ceil(maxTime) + 1 }, (_, i) => (
                                    <Box
                                        key={`v-${i}`}
                                        sx={{
                                            position: "absolute",
                                            left: `${i * 40}px`,
                                            top: 0,
                                            width: "1px",
                                            height: "100%",
                                            bgcolor: i === 0 ? "#a5b4fc" : "#c7d2fe",
                                            zIndex: 1,
                                        }}
                                    />
                                ))}

                                {/* JOBS */}
                                <Box sx={{ position: "relative", zIndex: 10 }}>
                                    {schedule.map(e => {
                                        const job = jobMap[e.jobId];
                                        if (!job || job.machine !== m) return null;
                                        return (
                                            <motion.div
                                                key={e.jobId}
                                                initial={{ opacity: 0, y: 10 }}
                                                animate={{ opacity: 1, y: 0 }}
                                                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                                                style={{
                                                    position: "absolute",
                                                    left: `${e.start * 40}px`,
                                                    top: 5,
                                                    width: `${e.duration * 40 - 6}px`,
                                                    height: 24,
                                                    background: colors[job.id % colors.length],
                                                    borderRadius: 10,
                                                    display: "flex",
                                                    alignItems: "center",
                                                    justifyContent: "center",
                                                    color: "white",
                                                    fontSize: 10,
                                                    fontWeight: 700,
                                                    boxShadow: highlight.includes(job.id)
                                                        ? "0 0 20px rgba(99,102,241,0.8)"
                                                        : "0 4px 16px rgba(0,0,0,0.25)",
                                                    border: "1px solid rgba(255,255,255,0.3)",
                                                }}
                                            >
                                                {job.name}
                                            </motion.div>
                                        );
                                    })}
                                </Box>
                            </Box>
                        </Box>
                    ))}
                </Box>
            </Box>
        </Paper>
    );
};

export default MiniGantt;