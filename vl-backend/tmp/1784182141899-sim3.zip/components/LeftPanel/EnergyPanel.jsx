// src/components/LeftPanel/EnergyPanel.jsx
import React from "react";
import {
  Box,
  Paper,
  Typography,
  Stack,
  Divider,
  Chip,
} from "@mui/material";
import { Functions } from "@mui/icons-material";

const EnergyPanel = ({
  energy = 0,
  activeConstraints = [],
  dependencyConstraints = [],
  constraintOptions, // Pass constraintOptions as a prop
}) => {
  return (
    <Paper variant="outlined" sx={{ p: 2, mb: 3, bgcolor: "white" }}>
      <Stack spacing={1}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Functions />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Total Hamiltonian Energy
          </Typography>
        </Box>

        <Typography variant="h4" sx={{ fontWeight: 700 }}>
          {Number(energy).toFixed(2)}
        </Typography>

        <Typography variant="body2" color="text.secondary">
          This is an absolute energy score — higher values indicate more
          constraint penalties and a harder VQE optimization.
        </Typography>

        <Divider sx={{ my: 1 }} />

        <Typography variant="subtitle2">Contributing penalties</Typography>
        <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", mt: 1 }}>
          {activeConstraints.length === 0 &&
            dependencyConstraints.length === 0 && (
              <Typography variant="caption" color="text.secondary">
                No active penalties
              </Typography>
            )}
          {activeConstraints.map((id) => {
            const co = constraintOptions.find((c) => c.id === id);
            if (!co) return null;
            return (
              <Chip
                key={id}
                label={`${co.label} (+${co.penalty})`}
                size="small"
              />
            );
          })}

          {dependencyConstraints.map((d, i) => (
            <Chip
              key={`dep-${i}`}
              label={`Dep ${d.firstJobId}→${
                d.secondJobId
              } (+${d.penalty.toFixed(1)})`}
              size="small"
            />
          ))}
        </Box>
      </Stack>
    </Paper>
  );
};

export default EnergyPanel;