// src/components/LeftPanel/MotionPaper.jsx
import { motion } from "framer-motion";
import { Paper } from "@mui/material";

const MotionPaper = motion(Paper);

export default MotionPaper;