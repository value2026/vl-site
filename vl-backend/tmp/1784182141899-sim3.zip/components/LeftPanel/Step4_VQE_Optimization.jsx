// src/LeftPanel/Step4_VQE_Optimization.jsx
import React, { useState, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Box,
  Paper,
  Typography,
  Button,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  TextField,
  CircularProgress,
  Stack,
  LinearProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from "@mui/material";
import {
  ArrowBack,
  PlayArrow,
  Pause,
  CheckCircle,
} from "@mui/icons-material";
import { motion, AnimatePresence } from "framer-motion";
import {
  setStep,
  setTheta,
  setEnergy,
  setEnergyHistory,
  setThetaHistory,
  setSchedule,
  setOptimizationStarted,
  addEnergyHistoryEntry,
  addThetaHistoryEntry,
} from "../../redux/simulationSlice";

const MotionPaper = motion(Paper);
const MotionBox = motion(Box);

const Step4_VQE_Optimization = () => {
  const dispatch = useDispatch();
  const { jobs, theta, energyHistory, thetaHistory, dependencyConstraints } = useSelector(
    (state) => state.simulation
  );

  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationProgress, setOptimizationProgress] = useState(0);
  const [bestEnergy, setBestEnergy] = useState(Infinity);
  const [optimizer, setOptimizer] = useState("COBYLA");
  const [maxIterations, setMaxIterations] = useState(30);
  const optimizationTimeout = useRef(null);
  const [optimizationCompleted, setOptimizationCompleted] = useState(false);

  useEffect(() => {
    if (energyHistory.length > 0) {
      const minEnergy = Math.min(...energyHistory);
      if (minEnergy < bestEnergy) setBestEnergy(minEnergy);
    }
  }, [energyHistory, bestEnergy]);

  const handleStartOptimization = () => {
    dispatch(setOptimizationStarted(true));
    setIsOptimizing(true);
    setOptimizationCompleted(false);
    setOptimizationProgress(0);
    dispatch(setEnergyHistory([]));
    dispatch(setThetaHistory([]));

    let currentTheta = { ...theta };
    const stepDuration = 200;

    const runStep = (i) => {
      if (i >= maxIterations) {
        setIsOptimizing(false);
        setOptimizationCompleted(true);
        setOptimizationProgress(100);
        return;
      }

      const gradient = {};
      Object.keys(currentTheta).forEach((key) => {
        gradient[key] = 2 * (currentTheta[key] - Math.PI / 2);
      });

      Object.keys(currentTheta).forEach((key) => {
        currentTheta[key] -= 0.1 * gradient[key];
      });

      const currentEnergy = Object.values(currentTheta).reduce(
        (acc, val) => acc + Math.pow(val - Math.PI / 2, 2),
        0
      );

      dispatch(setTheta({ ...currentTheta }));
      dispatch(setEnergy(currentEnergy));
      dispatch(addEnergyHistoryEntry(currentEnergy));
      dispatch(addThetaHistoryEntry({ ...currentTheta }));
      setOptimizationProgress(((i + 1) / maxIterations) * 100);

      optimizationTimeout.current = setTimeout(() => runStep(i + 1), stepDuration);
    };

    runStep(0);
  };

  const handleStopOptimization = () => {
    setIsOptimizing(false);
    if (optimizationTimeout.current) clearTimeout(optimizationTimeout.current);
  };

  const handleGetSchedule = () => {
    const jobWithThetas = jobs.map((job, index) => ({
      ...job,
      thetaValue: theta[index] || 0,
    }));

    const adj = new Map(jobs.map(j => [j.id, []]));
    const inDegree = new Map(jobs.map(j => [j.id, 0]));

    dependencyConstraints.forEach(d => {
      if (adj.has(d.firstJobId)) {
        adj.get(d.firstJobId).push(d.secondJobId);
        inDegree.set(d.secondJobId, (inDegree.get(d.secondJobId) || 0) + 1);
      }
    });

    const queue = jobs.filter(j => inDegree.get(j.id) === 0).map(j => j.id);
    const sortedJobIds = [];
    while (queue.length) {
      const id = queue.shift();
      sortedJobIds.push(id);
      if (adj.has(id)) {
        adj.get(id).forEach(n => {
          inDegree.set(n, inDegree.get(n) - 1);
          if (inDegree.get(n) === 0) queue.push(n);
        });
      }
    }

    const jobsInOrder = sortedJobIds.map(id => jobWithThetas.find(j => j.id === id));
    jobs.forEach(job => {
      if (!sortedJobIds.includes(job.id)) {
        jobsInOrder.push(jobWithThetas.find(j => j.id === job.id));
      }
    });

    const machineTimes = {};
    const newSchedule = [];
    const scheduledJobs = new Map();

    jobsInOrder.forEach((job) => {
      const machine = job.machine || "Machine 1";
      machineTimes[machine] = (machineTimes[machine] || 0);
      
      let earliestStartTime = machineTimes[machine];
      const jobDependencies = dependencyConstraints.filter(d => d.secondJobId === job.id);
      
      jobDependencies.forEach(dep => {
        const predecessor = scheduledJobs.get(dep.firstJobId);
        if (predecessor) {
          earliestStartTime = Math.max(earliestStartTime, predecessor.endTime);
        }
      });

      const startTime = earliestStartTime;
      const endTime = startTime + job.duration;
      machineTimes[machine] = endTime;

      const scheduleEntry = { job: job.name, machine, startTime, endTime, jobId: job.id };
      newSchedule.push(scheduleEntry);
      scheduledJobs.set(job.id, scheduleEntry);
    });

    dispatch(setSchedule(newSchedule));
  };

  useEffect(() => {
    if (optimizationCompleted) {
      handleGetSchedule();
    }
  }, [optimizationCompleted]);

  return (
    <Box
      sx={{
        height: "100vh",
        overflowY: "auto",
        overflowX: "hidden",
        bgcolor: "#f8f9fa",
        p: { xs: 2, sm: 3 },
        pt: { xs: 3, sm: 4 },
        pb: 2, // Reduced bottom padding
        boxSizing: "border-box",
        "&::-webkit-scrollbar": { width: "8px" },
        "&::-webkit-scrollbar-track": { background: "#f1f1f1", borderRadius: "10px" },
        "&::-webkit-scrollbar-thumb": { background: "#888", borderRadius: "10px" },
        "&::-webkit-scrollbar-thumb:hover": { background: "#555" },
      }}
    >
      {/* HEADER */}
      <MotionPaper
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
        elevation={12}
        sx={{
          mb: 3,
          p: { xs: 2.5, md: 3 },
          borderRadius: 4,
          background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
          color: "white",
          boxShadow: "0 12px 40px rgba(99,102,241,0.35)",
        }}
      >
        <Typography variant="h6" sx={{ fontWeight: 900, fontSize: { xs: "1.1rem", md: "1.25rem" } }}>
          Step 4 — VQE Quantum Optimization
        </Typography>
        <Typography variant="body2" sx={{ opacity: 0.95, mt: 1, fontSize: "0.85rem" }}>
          Each job becomes a qubit • Rx(θ) = scheduling bias • CNOT = precedence constraints
        </Typography>
      </MotionPaper>

      <Alert severity="info" sx={{ mb: 3, borderRadius: 3, fontSize: "0.875rem" }}>
        <strong>Classical Optimizer:</strong> Uses a gradient-based or derivative-free method (e.g., COBYLA, SPSA) to iteratively update θ values.
      </Alert>

      {/* MAIN CONTENT — Equal Height Panels */}
      <Grid container spacing={3} sx={{ flexGrow: 1 }}>
        {/* LEFT: Optimizer Panel */}
        <Grid item xs={12} md={7}>
          <MotionPaper
            elevation={6}
            sx={{
              p: { xs: 2.5, md: 3 },
              borderRadius: 4,
              bgcolor: "white",
              height: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Typography variant="h6" fontWeight={700} mb={2} sx={{ fontSize: "1.1rem" }}>
              Classical Optimizer Panel
            </Typography>

            <Grid container spacing={2} mb={3}>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth size="small">
                  <InputLabel>Optimizer</InputLabel>
                  <Select value={optimizer} onChange={(e) => setOptimizer(e.target.value)}>
                    <MenuItem value="COBYLA">COBYLA</MenuItem>
                    <MenuItem value="SPSA">SPSA</MenuItem>
                    <MenuItem value="NELDER_MEAD">Nelder-Mead</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  size="small"
                  label="Max Iterations"
                  type="number"
                  value={maxIterations}
                  onChange={(e) => setMaxIterations(parseInt(e.target.value))}
                  inputProps={{ min: 1 }}
                />
              </Grid>
            </Grid>

            <Box textAlign="center" mb={3} flexGrow={1} display="flex" flexDirection="column" justifyContent="center">
              <AnimatePresence mode="wait">
                <MotionBox
                  key={energyHistory[energyHistory.length - 1]}
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring" }}
                >
                  <Typography variant="h4" sx={{ fontWeight: 900, color: "#6366f1" }}>
                    {energyHistory.length > 0 ? energyHistory[energyHistory.length - 1].toFixed(6) : "—"}
                  </Typography>
                </MotionBox>
              </AnimatePresence>
              <Typography variant="body2" color="text.secondary">Energy</Typography>
            </Box>

            <Box mb={3}>
              <LinearProgress variant="determinate" value={optimizationProgress} sx={{ height: 12, borderRadius: 6 }} />
              <Typography align="center" sx={{ mt: 1, fontWeight: 600, fontSize: "0.875rem" }}>
                Iteration {energyHistory.length} / {maxIterations} • {Math.round(optimizationProgress)}%
              </Typography>
            </Box>

            <Box textAlign="center">
              <AnimatePresence mode="wait">
                {!isOptimizing && !optimizationCompleted && (
                  <MotionBox key="start">
                    <Button variant="contained" startIcon={<PlayArrow />} onClick={handleStartOptimization} size="large">
                      Start Optimization
                    </Button>
                  </MotionBox>
                )}
                {isOptimizing && (
                  <MotionBox key="run">
                    <Stack spacing={2} alignItems="center">
                      <Button variant="contained" color="error" startIcon={<Pause />} onClick={handleStopOptimization}>
                        Pause
                      </Button>
                      <CircularProgress variant="determinate" value={optimizationProgress} size={70} thickness={5} />
                      <Typography variant="h6" color="#6366f1">Optimizing... {Math.round(optimizationProgress)}%</Typography>
                    </Stack>
                  </MotionBox>
                )}
                {optimizationCompleted && (
                  <MotionBox key="done">
                    <Stack spacing={2} alignItems="center">
                      <CheckCircle sx={{ fontSize: 70, color: "#6366f1" }} />
                      <Typography variant="h6" fontWeight={800} color="#6366f1">
                        Optimization Complete!
                      </Typography>
                    </Stack>
                  </MotionBox>
                )}
              </AnimatePresence>
            </Box>
          </MotionPaper>
        </Grid>

        {/* RIGHT: Parameter Table */}
        <Grid item xs={12} md={5}>
          <MotionPaper
            elevation={6}
            sx={{
              p: 3,
              borderRadius: 4,
              bgcolor: "white",
              height: "100%", // EXACT SAME HEIGHT
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Typography variant="h6" fontWeight={700} mb={2} sx={{ fontSize: "1.1rem" }}>
              Parameter Evolution
            </Typography>

            <TableContainer sx={{ flex: 1 }}>
              <Table stickyHeader size="small">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: 700 }}>Iter</TableCell>
                    {Object.keys(theta).slice(0, 6).map((key) => (
                      <TableCell key={key} align="center" sx={{ fontWeight: 700 }}>θ{key}</TableCell>
                    ))}
                    {Object.keys(theta).length > 6 && <TableCell align="center">...</TableCell>}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {thetaHistory.slice(-15).reverse().map((row, idx) => (
                    <TableRow key={idx} hover>
                      <TableCell>{thetaHistory.length - idx}</TableCell>
                      {Object.values(row).slice(0, 6).map((val, i) => (
                        <TableCell key={i} align="center">{val.toFixed(4)}</TableCell>
                      ))}
                      {Object.keys(theta).length > 6 && <TableCell>...</TableCell>}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </MotionPaper>
        </Grid>
      </Grid>

      {/* Back Button — No extra space */}
      <Box sx={{ mt: 3, textAlign: "left" }}>
        <Button variant="outlined" startIcon={<ArrowBack />} onClick={() => dispatch(setStep(3))}>
          Back to Ansatz
        </Button>
      </Box>
    </Box>
  );
};

export default Step4_VQE_Optimization;