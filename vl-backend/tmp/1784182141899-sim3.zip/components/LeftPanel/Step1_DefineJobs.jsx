// Step1_DefineJobs.jsx - Compact + Keeps Your Beautiful Job Cards
import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  IconButton,
  Chip,
  Paper,
  Stack,
  Avatar,
  Zoom,
  Fade,
  alpha,
  InputAdornment,
  TextField,
} from "@mui/material";
import {
  Add as AddIcon,
  PlayArrow,
  Schedule,
  Devices,
  DeleteOutline,
  WorkOutline as WorkOutlineIcon,
} from "@mui/icons-material";
import { motion } from "framer-motion";
import { setStep, addJob, deleteJob as deleteJobAction } from "../../redux/simulationSlice";

const MotionCard = motion(Card);

const Step1_DefineJobs = () => {
  const dispatch = useDispatch();
  const { jobs, nextId, machines, suggestedJobNames } = useSelector((state) => state.simulation);

  const [newName, setNewName] = useState("");
  const [newDuration, setNewDuration] = useState(5);
  const [newMachine, setNewMachine] = useState(machines[0] || "");
  const [duplicateError, setDuplicateError] = useState("");

  const topSuggestions = (suggestedJobNames || []).slice(0, 6);
  const availableJobNames = topSuggestions.filter(
    (name) => !jobs.some((j) => j.name.toLowerCase() === name.toLowerCase())
  );

  useEffect(() => {
    if (!newName && availableJobNames.length > 0) setNewName(availableJobNames[0]);
    if (machines.length > 0 && !newMachine) setNewMachine(machines[0]);
  }, [availableJobNames, newName, machines, newMachine]);

  const isDuplicate = (name) =>
    jobs.some((j) => j.name.toLowerCase() === name.trim().toLowerCase());

  const handleAddJob = () => {
    const name = newName.trim();
    if (!name || newDuration < 1) return;
    if (isDuplicate(name)) {
      setDuplicateError("Already exists");
      return;
    }

    dispatch(addJob({
      id: nextId,
      name,
      duration: Number(newDuration),
      machine: newMachine,
      sector: "IT",
      dependencies: [],
    }));

    const next = availableJobNames.find((n) => n !== name);
    setNewName(next || "");
    setNewDuration(5);
    setDuplicateError("");
  };

  const handleDeleteJob = (id) => {
    if (window.confirm("Delete job?")) {
      dispatch(deleteJobAction(id));
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        height: "100vh",
        bgcolor: "#f9fbfc",
        p: { xs: 2, sm: 3 },
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Compact Header */}
      <Fade in timeout={600}>
        <Box
          sx={{
            mb: 3,
            p: { xs: 2.5, md: 3 },
            borderRadius: 3,
            background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
            color: "white",
            boxShadow: "0 8px 25px rgba(99,102,241,0.25)",
          }}
        >
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 0.5 }}>
            Step 1 — Define Jobs
          </Typography>
          <Typography variant="body2" sx={{ opacity: 0.9 }}>
            Add jobs with name, duration, and machine
          </Typography>
        </Box>
      </Fade>

      {/* Compact Add Form */}
      <Paper
        elevation={8}
        sx={{
          mb: 3,
          p: 2.5,
          borderRadius: 3,
          bgcolor: "white",
          position: "sticky",
          top: 16,
          zIndex: 10,
          boxShadow: "0 4px 20px rgba(0,0,0,0.08)",
        }}
      >
        <Stack direction="row" alignItems="center" spacing={1.5} mb={2}>
          <Box sx={{ bgcolor: "primary.main", p: 1, borderRadius: 2 }}>
            <WorkOutlineIcon sx={{ color: "white", fontSize: 22 }} />
          </Box>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>Add Job</Typography>
        </Stack>

        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={5}>
            <FormControl fullWidth size="small" error={Boolean(duplicateError)}>
              <InputLabel>Job Name</InputLabel>
              <Select
                value={newName}
                label="Job Name"
                onChange={(e) => {
                  setNewName(e.target.value);
                  setDuplicateError("");
                }}
              >
                {availableJobNames.length > 0 ? (
                  availableJobNames.map((name) => (
                    <MenuItem key={name} value={name}>{name}</MenuItem>
                  ))
                ) : (
                  <MenuItem disabled><em>No suggestions</em></MenuItem>
                )}
              </Select>
            </FormControl>
            {duplicateError && (
              <Typography color="error" variant="caption" sx={{ mt: 0.5, ml: 1 }}>
                {duplicateError}
              </Typography>
            )}
          </Grid>

          <Grid item xs={6} sm={4} md={2}>
            <TextField
              label="Duration"
              type="number"
              size="small"
              value={newDuration}
              onChange={(e) => setNewDuration(Math.max(1, Number(e.target.value) || 1))}
              fullWidth
              InputProps={{ endAdornment: <InputAdornment position="end">h</InputAdornment> }}
            />
          </Grid>

          <Grid item xs={6} sm={4} md={3}>
            <FormControl fullWidth size="small">
              <InputLabel>Machine</InputLabel>
              <Select value={newMachine} label="Machine" onChange={(e) => setNewMachine(e.target.value)}>
                {machines.map((m) => (
                  <MenuItem key={m} value={m}>
                    <Devices fontSize="small" sx={{ mr: 1 }} /> {m}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={4} md={2}>
            <Zoom in={newName && newDuration >= 1}>
              <Button
                variant="contained"
                size="medium"
                fullWidth
                startIcon={<AddIcon />}
                onClick={handleAddJob}
                sx={{
                  height: 40,
                  fontWeight: 600,
                  background: "linear-gradient(45deg, #6366f1, #8b5cf6)",
                  boxShadow: "0 4px 15px rgba(99,102,241,0.3)",
                }}
              >
                Add
              </Button>
            </Zoom>
          </Grid>
        </Grid>
      </Paper>

      {/* Your Beautiful Job Cards — Kept & Slightly Tightened */}
      <Box sx={{ flex: 1, overflow: "auto" }}>
        <Typography variant="h6" fontWeight={600} mb={2}>
          Your Jobs ({jobs.length})
        </Typography>

        {jobs.length === 0 ? (
          <Paper
            sx={{
              p: 6,
              textAlign: "center",
              borderRadius: 3,
              bgcolor: alpha("#6366f1", 0.04),
              border: "2px dashed",
              borderColor: alpha("#6366f1", 0.3),
            }}
          >
            <WorkOutlineIcon sx={{ fontSize: 60, color: "primary.main", opacity: 0.6, mb: 2 }} />
            <Typography variant="h6" color="text.secondary">No jobs added yet</Typography>
          </Paper>
        ) : (
          <Grid container spacing={2.5}>
            {jobs.map((job, i) => (
              <Grid item xs={12} sm={6} md={4} key={job.id}>
                <Zoom in timeout={180 + i * 80}>
                  <MotionCard
                    variant="outlined"
                    sx={{
                      height: "100%",
                      borderRadius: 3,
                      borderColor: "grey.300",
                      bgcolor: "white",
                      transition: "all 0.3s ease",
                      "&:hover": {
                        transform: "translateY(-6px)",
                        boxShadow: "0 12px 28px rgba(0,0,0,0.12)",
                        borderColor: "primary.main",
                      },
                    }}
                    whileHover={{ y: -4 }}
                  >
                    <CardContent sx={{ p: 2.5 }}>
                      <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                        <Box sx={{ display: "flex", gap: 1.8, alignItems: "center" }}>
                          <Avatar
                            sx={{
                              bgcolor: "primary.main",
                              width: 48,
                              height: 48,
                              fontSize: "1.3rem",
                              fontWeight: 700,
                            }}
                          >
                            {job.name[0].toUpperCase()}
                          </Avatar>
                          <Box>
                            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: "1.1rem" }}>
                              {job.name}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                              {job.sector}
                            </Typography>
                          </Box>
                        </Box>
                        <IconButton
                          size="small"
                          onClick={() => handleDeleteJob(job.id)}
                          sx={{ color: "error.main" }}
                        >
                          <DeleteOutline fontSize="small" />
                        </IconButton>
                      </Stack>

                      <Stack direction="row" spacing={1.5} mt={2}>
                        <Chip
                          icon={<Schedule sx={{ fontSize: 16 }} />}
                          label={`${job.duration} hour${job.duration > 1 ? "s" : ""}`}
                          size="small"
                          color="primary"
                          variant="outlined"
                        />
                        <Chip
                          icon={<Devices sx={{ fontSize: 16 }} />}
                          label={job.machine}
                          size="small"
                          sx={{ bgcolor: alpha("#10b981", 0.1), color: "#166534" }}
                        />
                      </Stack>
                    </CardContent>
                  </MotionCard>
                </Zoom>
              </Grid>
            ))}
          </Grid>
        )}
      </Box>

      {/* Fixed Bottom */}
      <Box
        sx={{
          mt: 3,
          pt: 2,
        
          borderColor: "divider",
      
          textAlign: "right",
        }}
      >
        <Fade in={jobs.length > 0}>
          <Button
            variant="contained"
            size="large"
            endIcon={<PlayArrow />}
            onClick={() => dispatch(setStep(2))}
            disabled={jobs.length === 0}
            sx={{
              px: 4,
              py: 1.5,
              fontWeight: 600,
              borderRadius: 2,
              background: "linear-gradient(45deg, #4f46e5, #7c3aed)",
              boxShadow: "0 6px 20px rgba(79,70,229,0.3)",
            }}
          >
            Next: Define Rules
          </Button>
        </Fade>
      </Box>
    </Box>
  );
};

export default Step1_DefineJobs;