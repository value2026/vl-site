// src/components/LeftPanel/CircuitDiagram.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import {
    Box,
    Typography,
    Stack,
    useTheme,
    alpha,
} from "@mui/material";
import { motion } from "framer-motion";

const CircuitDiagram = () => {
    const { jobs, dependencyConstraints, theta } = useSelector((state) => state.simulation);
    const jobToQubit = Object.fromEntries(jobs.map((j, i) => [j.id, i]));
    const theme = useTheme();

    return (
        <Box
            sx={{
                bgcolor: "white",
                borderRadius: 2,
                border: `1px solid ${alpha(theme.palette.primary.main, 0.15)}`,
                p: 1.5,
                boxShadow: "0 4px 16px rgba(0,0,0,0.06)",
                overflowX: "auto",
                fontFamily: "monospace",
                maxHeight: "100%",
            }}
        >
            <Box sx={{ position: "relative", minWidth: 520, height: jobs.length * 56 + 40 }}>
                {/* QUBIT LINES */}
                {jobs.map((job, i) => {
                    const y = i * 56 + 28;
                    return (
                        <Box key={job.id} sx={{ position: "absolute", top: y - 28, left: 0, width: "100%", height: 56, display: "flex", alignItems: "center" }}>
                            <Typography sx={{ width: 60, pr: 1, textAlign: "right", fontSize: "0.78rem", fontWeight: 700, color: "primary.main" }}>
                                q[{i}]
                            </Typography>
                            <Typography sx={{ width: 90, fontSize: "0.75rem", color: "text.secondary", fontWeight: 500, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                                {job.name}
                            </Typography>
                            <Box sx={{ flex: 1, height: 1.8, bgcolor: "grey.300", mx: 1.5 }}>
                                <motion.div
                                    initial={{ scaleX: 0 }}
                                    animate={{ scaleX: 1 }}
                                    transition={{ duration: 0.8, delay: i * 0.08 }}
                                    style={{
                                        height: "100%",
                                        background: "linear-gradient(90deg, #8b5cf6, #6366f1)",
                                        transformOrigin: "left",
                                    }}
                                />
                            </Box>
                        </Box>
                    );
                })}

                {/* Rx GATES */}
                {jobs.map((_, i) => {
                    const y = i * 56 + 28;
                    return (
                        <motion.div
                            key={i}
                            initial={{ opacity: 0, scale: 0.5 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ type: "spring", stiffness: 500, delay: 0.6 + i * 0.08 }}
                            style={{
                                position: "absolute",
                                left: 170,
                                top: y - 14,
                                width: 36,
                                height: 28,
                                background: "white",
                                border: "2.2px solid #8b5cf6",
                                borderRadius: 7,
                                boxShadow: "0 4px 12px rgba(139,92,246,0.25)",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                fontWeight: "bold",
                                color: "#6d28d9",
                                fontSize: 10,
                            }}
                        >
                            Rx
                        </motion.div>
                    );
                })}

                {/* CNOT GATES */}
                {dependencyConstraints.slice(0, 4).map((dep, idx) => {
                    const c = jobToQubit[dep.firstJobId];
                    const t = jobToQubit[dep.secondJobId];
                    if (c === undefined || t === undefined) return null;

                    const x = 230 + idx * 55;
                    const cy = c * 56 + 28;
                    const ty = t * 56 + 28;

                    return (
                        <motion.div key={idx} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1 + idx * 0.1 }}>
                            <Box sx={{ position: "absolute", left: x + 18, top: Math.min(cy, ty) - 10, width: 2.2, height: Math.abs(cy - ty) + 20, bgcolor: "#6366f1", transform: "translateX(-50%)" }} />
                            <Box sx={{ position: "absolute", left: x + 18, top: cy - 6, width: 12, height: 12, bgcolor: "#6366f1", borderRadius: "50%", transform: "translateX(-50%)" }} />
                            <Box sx={{ position: "absolute", left: x + 18, top: ty - 8, width: 18, height: 18, border: "2.8px solid #6366f1", borderRadius: "50%", bgcolor: "white", transform: "translateX(-50%)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: "bold", color: "#6366f1" }}>
                                +
                            </Box>
                        </motion.div>
                    );
                })}

                {/* θ VALUES */}
                {jobs.map((_, i) => {
                    const y = i * 56 + 28;
                    return (
                        <motion.div
                            key={`theta-${i}`}
                            initial={{ opacity: 0, x: 30 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.9 + i * 0.08 }}
                            style={{
                                position: "absolute",
                                right: 16,
                                top: y - 12,
                                background: "#f3e8ff",
                                color: "#7c3aed",
                                fontSize: 10,
                                fontWeight: 700,
                                padding: "4px 10px",
                                borderRadius: 16,
                                border: "1px solid #e9d5ff",
                                boxShadow: "0 2px 8px rgba(124,58,237,0.15)",
                                minWidth: 70,
                                textAlign: "center",
                            }}
                        >
                            θ{i} = {(theta[i] || 0).toFixed(2)}
                        </motion.div>
                    );
                })}
            </Box>

            {/* LEGEND */}
            <Stack direction="row" spacing={3} mt={2} justifyContent="center" fontSize="0.75rem" color="text.secondary">
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Box sx={{ width: 36, height: 28, border: "2.2px solid #8b5cf6", borderRadius: 2, bgcolor: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: "bold", color: "#6d28d9", fontSize: 10 }}>Rx</Box>
                    <span>Bias</span>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Box sx={{ width: 12, height: 12, bgcolor: "#6366f1", borderRadius: "50%" }} />
                    <span>Ctrl</span>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                    <Box sx={{ width: 18, height: 18, border: "2.8px solid #6366f1", borderRadius: "50%", bgcolor: "white", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: "#6366f1", fontWeight: "bold" }}>+</Box>
                    <span>Target</span>
                </Box>
            </Stack>
        </Box>
    );
};

export default CircuitDiagram;