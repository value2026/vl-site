// src/components/Step2_ConstraintsVQE.jsx
import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Box,
  Paper,
  Typography,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button,
  Chip,
  Stack,
  Fade,
  Zoom,
  alpha,
  IconButton,
} from "@mui/material";
import {
  ArrowBack,
  PlayArrow,
  Link as LinkIcon,
  DeleteOutline,
  Add as AddIcon,
  ArrowForward as ArrowForwardIcon,
} from "@mui/icons-material";
import { motion } from "framer-motion";
import { setStep, addDependency, removeDependency } from "../../redux/simulationSlice";
import { selectHamiltonian } from "../../redux/simulationSlice";
import MiniGantt from "./MiniGantt";

const MotionPaper = motion(Paper);

const Step2_ConstraintsVQE = () => {
  const dispatch = useDispatch();
  const { jobs, dependencyConstraints } = useSelector((state) => state.simulation);
  const hamiltonian = useSelector(selectHamiltonian);

  const [firstJob, setFirstJob] = useState("");
  const [secondJob, setSecondJob] = useState("");
  const [highlight, setHighlight] = useState([]);

  const energy = dependencyConstraints.length * 1.0;

  useEffect(() => {
    if (jobs.length > 0 && !firstJob) setFirstJob(jobs[0].id);
    if (jobs.length > 1 && !secondJob) setSecondJob(jobs[1].id);
  }, [jobs, firstJob, secondJob]);

  const handleAddDependency = () => {
    if (!firstJob || !secondJob || firstJob === secondJob) return;
    const exists = dependencyConstraints.some(
      d => d.firstJobId === +firstJob && d.secondJobId === +secondJob
    );
    if (exists) return;

    dispatch(addDependency({ firstJobId: +firstJob, secondJobId: +secondJob, penalty: 1.0 }));
    setHighlight([+firstJob, +secondJob]);
    setTimeout(() => setHighlight([]), 1000);

    const nextIndex = jobs.findIndex(j => j.id === +secondJob) + 1;
    if (nextIndex < jobs.length) setSecondJob(jobs[nextIndex].id);
  };

  const handleRemoveDependency = (i) => dispatch(removeDependency(i));

  return (
    <Box
      sx={{
        height: "100vh",
        overflowY: "auto",
        overflowX: "hidden",
        bgcolor: "#f9fbfc",
        p: { xs: 2, sm: 3 },
        pt: { xs: 3, sm: 4 },
        pb: 4,
        boxSizing: "border-box",
        "&::-webkit-scrollbar": {
          width: "10px",
        },
        "&::-webkit-scrollbar-track": {
          background: "transparent",
        },
        "&::-webkit-scrollbar-thumb": {
          background: alpha("#6366f1", 0.3),
          borderRadius: "10px",
        },
        "&::-webkit-scrollbar-thumb:hover": {
          background: alpha("#6366f1", 0.5),
        },
      }}
    >
      {/* Header */}
      <Fade in timeout={700}>
        <Box
          sx={{
            mb: 3,
            p: { xs: 2.5, md: 3 },
            borderRadius: 4,
            background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
            color: "white",
            boxShadow: "0 10px 30px rgba(99,102,241,0.3)",
          }}
        >
          <Typography variant="h6" sx={{ fontWeight: 800 }}>
            Step 2 — Define Ordering Rules
          </Typography>
          <Typography variant="body1" sx={{ opacity: 0.95, mt: 0.5 }}>
            Each rule adds <Chip label="+1.0" size="small" sx={{ bgcolor: "rgba(255,255,255,0.3)", color: "white" }} /> to energy
          </Typography>
        </Box>
      </Fade>

      {/* Add Rule + Current Rules */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        {/* Add New Rule */}
        <Grid item xs={12} md={6}>
          <MotionPaper
            elevation={12}
            sx={{
              p: 3,
              borderRadius: 4,
              height: { xs: 300, md: 340 },
              bgcolor: "white",
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
            }}
          >
            <Stack spacing={3}>
              <Stack direction="row" alignItems="center" spacing={1.5}>
                <LinkIcon sx={{ fontSize: 22, color: "primary.main" }} />
                <Typography variant="h6" fontWeight={600}>Add New Rule</Typography>
              </Stack>

              <Grid container spacing={2} alignItems="center">
                <Grid item xs={12} sm={5}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Must Finish First</InputLabel>
                    <Select value={firstJob} onChange={e => setFirstJob(e.target.value)} label="Must Finish First">
                      {jobs.map(j => <MenuItem key={j.id} value={j.id}>{j.name}</MenuItem>)}
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={12} sm={2} sx={{ display: "flex", justifyContent: "center" }}>
                  <ArrowForwardIcon sx={{ fontSize: 40, color: "primary.main" }} />
                </Grid>

                <Grid item xs={12} sm={5}>
                  <FormControl fullWidth size="small">
                    <InputLabel>Can Start After</InputLabel>
                    <Select value={secondJob} onChange={e => setSecondJob(e.target.value)} label="Can Start After">
                      {jobs.map(j => (
                        <MenuItem key={j.id} value={j.id} disabled={j.id === +firstJob}>
                          {j.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
              </Grid>

              <Zoom in={firstJob && secondJob && firstJob !== secondJob}>
                <Box>
                  <Button
                    variant="contained"
                    size="large"
                    fullWidth
                    startIcon={<AddIcon />}
                    onClick={handleAddDependency}
                    sx={{
                      height: 52,
                      fontWeight: 700,
                      fontSize: "1rem",
                      background: "linear-gradient(45deg, #6366f1, #8b5cf6)",
                      boxShadow: "0 8px 25px rgba(99,102,241,0.35)",
                      borderRadius: 3,
                    }}
                  >
                    Add Rule (+1.0 energy)
                  </Button>
                </Box>
              </Zoom>
            </Stack>
          </MotionPaper>
        </Grid>

        {/* Current Rules */}
        <Grid item xs={12} md={6}>
          <MotionPaper
            elevation={12}
            sx={{
              p: 3,
              borderRadius: 4,
              height: { xs: 300, md: 340 },
              bgcolor: "white",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Stack direction="row" alignItems="center" justifyContent="space-between" mb={2}>
              <Typography variant="h6" fontWeight={600}>
                Current Rules ({dependencyConstraints.length})
              </Typography>
              <Chip label={`Energy: ${energy.toFixed(1)}`} color="primary" size="small" />
            </Stack>

            <Box
              sx={{
                flex: 1,
                overflowY: "auto",
                pr: 1,
                "&::-webkit-scrollbar": { width: 6 },
                "&::-webkit-scrollbar-thumb": { background: alpha("#6366f1", 0.3), borderRadius: 4 },
              }}
            >
              {dependencyConstraints.length === 0 ? (
                <Box sx={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "text.secondary" }}>
                  <Typography variant="body2" fontStyle="italic">
                    No ordering rules defined yet
                  </Typography>
                </Box>
              ) : (
                <Stack spacing={2}>
                  {dependencyConstraints.map((d, i) => {
                    const from = jobs.find(j => j.id === d.firstJobId)?.name || "?";
                    const to = jobs.find(j => j.id === d.secondJobId)?.name || "?";
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.05 }}
                      >
                        <Paper
                          elevation={4}
                          sx={{
                            p: 2.4,
                            borderRadius: 3,
                            bgcolor: alpha("#6366f1", 0.09),
                            border: `1px solid ${alpha("#6366f1", 0.15)}`,
                            "&:hover": { bgcolor: alpha("#6366f1", 0.14) },
                          }}
                        >
                          <Stack direction="row" justifyContent="space-between" alignItems="center">
                            <Stack direction="row" alignItems="center" spacing={2}>
                              <Chip label={from} color="primary" size="small" sx={{ fontWeight: 600 }} />
                              <ArrowForwardIcon sx={{ color: "primary.main", fontSize: 20 }} />
                              <Chip label={to} color="secondary" size="small" sx={{ fontWeight: 600 }} />
                            </Stack>
                            <IconButton
                              onClick={() => handleRemoveDependency(i)}
                              size="small"
                              sx={{ bgcolor: alpha("#ef4444", 0.1), "&:hover": { bgcolor: alpha("#ef4444", 0.2) } }}
                            >
                              <DeleteOutline fontSize="small" />
                            </IconButton>
                          </Stack>
                        </Paper>
                      </motion.div>
                    );
                  })}
                </Stack>
              )}
            </Box>
          </MotionPaper>
        </Grid>
      </Grid>

      {/* Live Preview — Takes remaining space */}
      <Box sx={{ minHeight: 280, mb: 3 }}>
        <MiniGantt highlight={highlight} />
      </Box>

      {/* Bottom Navigation — Sticky */}
      <Box
        sx={{
          mt: "auto",
          pt: 2,
          pb: 3,
          display: "flex",
          justifyContent: "space-between",
          position: "sticky",
          bottom: 0,
          bgcolor: "#f9fbfc",
          zIndex: 10,
          borderTop: "1px solid #e0e0e0",
        }}
      >
        <Button variant="outlined" size="large" startIcon={<ArrowBack />} onClick={() => dispatch(setStep(1))}>
          Back to Jobs
        </Button>
        <Button
          variant="contained"
          size="large"
          endIcon={<PlayArrow />}
          onClick={() => dispatch(setStep(3))}
          sx={{
            px: 5,
            py: 1.8,
            fontWeight: 700,
            borderRadius: 3,
            background: "linear-gradient(45deg, #4f46e5, #7c3aed)",
            boxShadow: "0 8px 25px rgba(79,70,229,0.4)",
          }}
        >
          Next: Design Quantum Circuit
        </Button>
      </Box>
    </Box>
  );
};

export default Step2_ConstraintsVQE;