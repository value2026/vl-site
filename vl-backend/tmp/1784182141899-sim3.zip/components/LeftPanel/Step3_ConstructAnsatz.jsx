// src/LeftPanel/Step3_ConstructAnsatz.jsx
import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  Box,
  Paper,
  Typography,
  Grid,
  Button,
  Stack,
  Chip,
  Slider,
  IconButton,
  Divider,
  useTheme,
  alpha,
  Popover,
} from "@mui/material";
import {
  ArrowBack,
  PlayArrow,
  Functions,
  Casino,
  Science,
  Tune,
  Info as InfoIcon,
} from "@mui/icons-material";
import { motion } from "framer-motion";
import { setStep, setTheta } from "../../redux/simulationSlice";
import CircuitDiagram from "./CircuitDiagram";

const MotionPaper = motion(Paper);

const Step3_ConstructAnsatz = () => {
  const dispatch = useDispatch();
  const { jobs, theta } = useSelector((state) => state.simulation);
  const theme = useTheme();
  const [anchorEl, setAnchorEl] = useState(null);

  const handleInfoClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  const randomizeTheta = () => {
    const newTheta = {};
    jobs.forEach((_, i) => (newTheta[i] = Math.random() * Math.PI));
    dispatch(setTheta(newTheta));
  };

  useEffect(() => {
    if (Object.keys(theta).length === 0 && jobs.length > 0) {
      const init = {};
      jobs.forEach((_, i) => (init[i] = Math.PI / 4));
      dispatch(setTheta(init));
    }
  }, [jobs, theta, dispatch]);

  return (
    <Box sx={{
      minHeight: "100vh",
      height: "100vh",
      bgcolor: "#f9fbfc",
      p: { xs: 2, sm: 3 },
      pt: { xs: 5, sm: 6 },
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
    }}>
      {/* HEADER */}
      <MotionPaper
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 300 }}
        elevation={12}
        sx={{
          mb: 3,
          p: { xs: 2.5, md: 3 },
          borderRadius: 3,
          background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)",
          color: "white",
          boxShadow: "0 12px 30px rgba(99, 102, 241, 0.3)",
        }}
      >
        <Stack direction="row" alignItems="center" spacing={2}>
          <Science sx={{ fontSize: 32 }} />
          <Box>
            <Typography variant="h5" sx={{ fontWeight: 800, letterSpacing: 0.5 }}>
              Step 3 — Construct Ansatz Circuit 
            </Typography>
            <Typography variant="body1" sx={{ opacity: 0.95, mt: 0.5, fontWeight: 500 }}>
              Tune θ to find the optimal job schedule (Rx is a single-qubit rotation)
            </Typography>
          </Box>
        </Stack>
      </MotionPaper>

      <Grid container spacing={3} sx={{ flex: 1 }}>
        {/* CIRCUIT */}
        <Grid item xs={12} md={6}>
          <MotionPaper
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            elevation={10}
            sx={{ p: 2, borderRadius: 3, height: "100%", bgcolor: "white", display: "flex", flexDirection: "column" }}
          >
            <Stack direction="row" alignItems="center" spacing={1} mb={1.5}>
              <Functions sx={{ fontSize: 22, color: "primary.main" }} />
              <Typography variant="h6" fontWeight={700}>
                Ansatz Circuit U(θ)
              </Typography>
            </Stack>
            <Box sx={{ flex: 1, overflow: "auto" }}>
              <CircuitDiagram />
            </Box>
          </MotionPaper>
        </Grid>

        {/* CONTROLS — SAME HEIGHT AS CIRCUIT */}
        <Grid item xs={12} md={6}>
          <MotionPaper
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            elevation={10}
            sx={{ 
              p: 3, 
              borderRadius: 3, 
              height: "100%", 
              bgcolor: "white", 
              display: "flex", 
              flexDirection: "column",
              minWidth: 420,
            }}
          >
            <Stack direction="row" alignItems="center" spacing={1.5} mb={2} justifyContent="space-between">
              <Stack direction="row" alignItems="center" spacing={1.5}>
                <Tune sx={{ fontSize: 24, color: "warning.main" }} />
                <Typography variant="h6" fontWeight={700}>
                  Tune θ Parameters
                </Typography>
              </Stack>
              <IconButton
                size="small"
                onClick={handleInfoClick}
                sx={{
                  bgcolor: alpha(theme.palette.info.main, 0.1),
                  "&:hover": { bgcolor: alpha(theme.palette.info.main, 0.2) },
                }}
              >
                <InfoIcon fontSize="small" color="info" />
              </IconButton>
            </Stack>

            {/* SLIDERS — 56px per job, NO GAP */}
            <Box sx={{ flex: 1, overflowY: "auto", pr: 1 }}>
              {jobs.map((job, i) => (
                <Box
                  key={i}
                  sx={{
                    height: 56,
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    px: 0.5,
                  }}
                >
                  <Stack direction="row" justifyContent="space-between" alignItems="center" mb={0.3}>
                    <Typography 
                      fontSize="0.85rem" 
                      fontWeight={600} 
                      sx={{ 
                        maxWidth: 180, 
                        overflow: "hidden", 
                        textOverflow: "ellipsis", 
                        whiteSpace: "nowrap" 
                      }}
                    >
                      θ{i} → {job.name}
                    </Typography>
                    <Chip 
                      label={(theta[i] || 0).toFixed(2)} 
                      size="small" 
                      color="warning" 
                      variant="outlined" 
                      sx={{ fontSize: "0.7rem", height: 20, fontWeight: 600 }} 
                    />
                  </Stack>
                  <Slider
                    size="small"
                    value={theta[i] || 0}
                    onChange={(_, v) => dispatch(setTheta({ ...theta, [i]: v }))}
                    min={0}
                    max={Math.PI}
                    step={0.01}
                    valueLabelDisplay="off"
                    sx={{ 
                      mt: 0,
                      "& .MuiSlider-thumb": { height: 14, width: 14 },
                      "& .MuiSlider-track": { height: 4 },
                      "& .MuiSlider-rail": { height: 4 },
                    }}
                  />
                </Box>
              ))}
            </Box>

            <Divider sx={{ my: 1.5 }} />

            <Stack spacing={1}>
              <Button 
                variant="contained" 
                startIcon={<Casino />} 
                onClick={randomizeTheta} 
                fullWidth
                size="small"
                sx={{ py: 1.2, fontWeight: 600 }}
              >
                Randomize
              </Button>
            </Stack>
          </MotionPaper>
        </Grid>
      </Grid>

      {/* INFO POPOVER */}
      <Popover
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
        PaperProps={{
          sx: {
            p: 3,
            maxWidth: 380,
            borderRadius: 3,
            boxShadow: "0 12px 40px rgba(0,0,0,0.15)",
            border: `1px solid ${alpha(theme.palette.info.main, 0.2)}`,
          },
        }}
      >
        <Stack spacing={2.5}>
          <Box>
            <Typography variant="subtitle1" fontWeight={700} color="info.main" gutterBottom>
              Why Tune θ?
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Each <strong>θᵢ</strong> controls how much qubit <strong>q[i]</strong> is rotated.
              <br />
              VQE adjusts θ to make <strong>⟨ψ|H|ψ⟩ as low as possible</strong> → perfect job order.
            </Typography>
          </Box>
          <Divider />
          <Box>
            <Typography variant="subtitle1" fontWeight={700} color="info.main" gutterBottom>
              Why Initialize?
            </Typography>
            <Typography variant="body2" color="text.secondary">
              We can't start from zero — need a <strong>good guess</strong>.
            
              {/* <strong>Smart Init</strong>: Start near π/4 (balanced state) */}
              <br />
              <strong>Random</strong>: Try many starting points
            </Typography>
          </Box>
        </Stack>
      </Popover>

      {/* BOTTOM BAR */}
      <Box sx={{ mt: 3, display: "flex", justifyContent: "space-between" }}>
        <Button variant="outlined" startIcon={<ArrowBack />} onClick={() => dispatch(setStep(2))}>
          Back
        </Button>
        <Button
          variant="contained"
          size="large"
          endIcon={<PlayArrow />}
          onClick={() => dispatch(setStep(4))}
          sx={{
            px: 6,
            fontWeight: 700,
            background: "linear-gradient(45deg, #4f46e5, #7c3aed)",
            boxShadow: "0 8px 25px rgba(79,70,229,0.4)",
          }}
        >
          Run VQE Optimization
        </Button>
      </Box>
    </Box>
  );
};

export default Step3_ConstructAnsatz;