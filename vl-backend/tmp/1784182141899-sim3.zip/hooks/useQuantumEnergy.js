// src/hooks/useQuantumEnergy.js
import { useMemo } from "react";
import { useSelector } from "react-redux";
import { selectHamiltonian } from "../redux/simulationSlice";

export const useQuantumEnergy = () => {
    const { jobs, dependencyConstraints, theta } = useSelector((state) => state.simulation);
    const hamiltonian = useSelector(selectHamiltonian);

    return useMemo(() => {
        const raw = Array.isArray(hamiltonian) ? hamiltonian.slice(1) : [];
        if (!raw.length || jobs.length === 0 || jobs.length > 6) return null;

        const cAdd = (a, b) => ({ re: a.re + b.re, im: a.im + b.im });
        const cMul = (a, b) => ({ re: a.re * b.re - a.im * b.im, im: a.re * b.im + a.im * b.re });
        const conj = (a) => ({ re: a.re, im: -a.im });

        const kron = (A, B) => {
            const n = A.length, m = B.length;
            const N = n * m;
            const R = Array.from({ length: N }, () => Array(N).fill({ re: 0, im: 0 }));
            for (let i = 0; i < n; i++)
                for (let j = 0; j < n; j++)
                    for (let p = 0; p < m; p++)
                        for (let q = 0; q < m; q++) {
                            const r = cMul(A[i][j], B[p][q]);
                            R[i * m + p][j * m + q] = r;
                        }
            return R;
        };

        const matVecMul = (M, v) => {
            const n = M.length;
            const out = Array(n).fill({ re: 0, im: 0 });
            for (let i = 0; i < n; i++) {
                let acc = { re: 0, im: 0 };
                for (let j = 0; j < n; j++) acc = cAdd(acc, cMul(M[i][j], v[j]));
                out[i] = acc;
            }
            return out;
        };

        const dotConj = (a, b) => {
            let acc = { re: 0, im: 0 };
            for (let i = 0; i < a.length; i++) acc = cAdd(acc, cMul(conj(a[i]), b[i]));
            return acc;
        };

        const Rx = (θ) => {
            const c = Math.cos(θ / 2);
            const s = Math.sin(θ / 2);
            return [
                [{ re: c, im: 0 }, { re: 0, im: -s }],
                [{ re: 0, im: -s }, { re: c, im: 0 }],
            ];
        };

        const CNOT = (nQ, control, target) => {
            const N = 1 << nQ;
            const M = Array.from({ length: N }, () => Array(N).fill({ re: 0, im: 0 }));
            for (let i = 0; i < N; i++) {
                const cBit = (i >> (nQ - 1 - control)) & 1;
                if (cBit === 0) M[i][i] = { re: 1, im: 0 };
                else {
                    const j = i ^ (1 << (nQ - 1 - target));
                    M[j][i] = { re: 1, im: 0 };
                }
            }
            return M;
        };

        const Pauli = {
            I: [[[1, 0], [0, 0]], [[0, 0], [1, 0]]].map(row => row.map(([re, im]) => ({ re, im }))),
            X: [[[0, 0], [1, 0]], [[1, 0], [0, 0]]].map(row => row.map(([re, im]) => ({ re, im }))),
            Y: [[[0, 0], [0, -1]], [[0, 1], [0, 0]]].map(row => row.map(([re, im]) => ({ re, im }))),
            Z: [[[1, 0], [0, 0]], [[0, 0], [-1, 0]]].map(row => row.map(([re, im]) => ({ re, im }))),
        };

        const buildPauliOp = (nQ, ops) => {
            let op = null;
            for (let q = 0; q < nQ; q++) {
                const label = ops[q] || "I";
                const mat = Pauli[label];
                op = op ? kron(op, mat) : mat;
            }
            return op;
        };

        const parsePauliTerms = (terms) => {
            const out = [];
            const re = /([+-]?\s*\d*\.?\d+)\s*\*?\s*([XYZ]\d+(?:\s*[XYZ]\d+)*)/i;
            terms.forEach((t) => {
                const s = t.replace(/\+/g, "").trim();
                const m = s.match(re);
                if (!m) return;
                const coeff = parseFloat(m[1]);
                const paulis = m[2].replace(/\s+/g, "");
                const tokens = paulis.match(/[XYZ]\d+/gi) || [];
                const ops = {};
                tokens.forEach((tok) => {
                    const p = tok[0].toUpperCase();
                    const idx = parseInt(tok.slice(1), 10);
                    ops[idx] = p;
                });
                out.push({ coeff, ops });
            });
            return out;
        };

        const n = jobs.length;
        const N = 1 << n;
        const zeroState = Array(N).fill({ re: 0, im: 0 });
        zeroState[0] = { re: 1, im: 0 };

        let U = Rx(theta[0] ?? 0);
        for (let q = 1; q < n; q++) U = kron(U, Rx(theta[q] ?? 0));
        let psi = matVecMul(U, zeroState);

        dependencyConstraints.forEach((d) => {
            const control = jobs.findIndex((j) => j.id === d.firstJobId);
            const target = jobs.findIndex((j) => j.id === d.secondJobId);
            if (control < 0 || target < 0) return;
            const C = CNOT(n, control, target);
            psi = matVecMul(C, psi);
        });

        let pauliTerms = parsePauliTerms(raw);
        if (pauliTerms.length === 0) {
            const orderRe = /([+-]?\s*\d*\.?\d+)\s*\*\s*Order\(([^,]+),\s*([^\)]+)\)/i;
            const derived = [];
            raw.forEach((t) => {
                const m = t.match(orderRe);
                if (m) {
                    const c = parseFloat(m[1]);
                    const a = jobs.findIndex((j) => j.name === m[2].trim());
                    const b = jobs.findIndex((j) => j.name === m[3].trim());
                    if (a >= 0 && b >= 0) {
                        derived.push(`${c / 2}*I`);
                        derived.push(`${-c / 2}*Z${a}Z${b}`);
                    }
                }
            });
            if (derived.length) pauliTerms = parsePauliTerms(derived);
        }

        let E = 0;
        const contributions = [];

        pauliTerms.forEach((pt) => {
            const op = buildPauliOp(n, pt.ops);
            const opPsi = matVecMul(op, psi);
            const val = dotConj(psi, opPsi);
            const exp = val.re;
            const contrib = pt.coeff * exp;
            E += contrib;

            const termStr = Object.entries(pt.ops)
                .sort(([a], [b]) => +a - +b)
                .map(([k, v]) => `${v}${k}`)
                .join("") || "I";
            contributions.push({ term: termStr, coeff: pt.coeff, expectation: exp, contrib });
        });

        return { value: E, contributions };
    }, [hamiltonian, theta, dependencyConstraints, jobs]);
};