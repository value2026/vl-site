import React, { useState } from "react";
import { connect, useSelector } from "react-redux";
import { Paper, Typography, Grid, IconButton } from "@mui/material";
import { useEffect } from "react";
import { ArrowBack, ArrowForward } from "@mui/icons-material";
import BoxComponent from "./step2";
import FinalStep from "./FinalStep";

const MessagePadding = () => {
  const [output, setOutput] = useState("");
  const { text } = useSelector((state) => state.md);
  const [showFinalStep, setShowFinalStep] = useState(false);
  useEffect(() => {
    if (text !== "") {
      const paddedOutput = calculateMD5Padding(text);
      setOutput(paddedOutput);
    }
  }, [text]);

  const handleNextClick = () => {
    setShowFinalStep(true);
  };

  const calculateMD5Padding = (texts) => {
    let binaryMessage = texts
      .split("")
      .map((char) => char.charCodeAt(0).toString(2))
      .join("");
    const originalLength = binaryMessage.length;

    binaryMessage += "1";

    const remainder = binaryMessage.length % 512;
    const paddingBits = (remainder < 448 ? 448 : 960) - remainder;
    binaryMessage += "0".repeat(paddingBits);

    binaryMessage += originalLength.toString(2).padStart(64, "0");

    return binaryMessage;
  };

  const renderBitRepresentation = (bitString) => {
    const firstFewBits = bitString.slice(0, 6);
    const lastFewBits = bitString.slice(-6);
    return firstFewBits + "......" + lastFewBits;
  };

//   const renderExtraGridSet = () => {
//     if (text.length > 64) {
//       const secondBlockOriginal = renderBitRepresentation(
//         output.slice(512, output.length - 64)
//       );
//       const secondBlockPadding =
//         "1" + "0".repeat(448 - (secondBlockOriginal.length % 448));
//       const secondBlockLength = renderBitRepresentation(
//         output.slice(output.length - 64)
//       );
// if(text.legth)
//       return (
        <></>
        // <>
        //   <Grid item xs={2}>
        //     <Typography
        //       variant="subtitle1"
        //       style={{ color: "grey", textAlign: "center" }}
        //     >
        //       Original Message Bit
        //     </Typography>
        //     <Paper
        //       elevation={3}
        //       style={{
        //         backgroundColor: "#f0f0f0",
        //         height: "70px",
        //         border: "1px solid #ccc",
        //         display: "flex",
        //         alignItems: "center",
        //         justifyContent: "center",
        //       }}
        //     >
        //       <Typography variant="body1" style={{ color: "grey" }}>
        //         {secondBlockOriginal}
        //       </Typography>
        //     </Paper>
        //   </Grid>
        //   <Grid item xs={2}>
        //     <Typography
        //       variant="subtitle1"
        //       style={{ color: "blue", textAlign: "center" }}
        //     >
        //       Padding Bits{" "}
        //     </Typography>
        //     <Paper
        //       elevation={3}
        //       style={{
        //         borderRadius: "5px",
        //         backgroundColor: "#f0f0f0",
        //         height: "70px",
        //         border: "1px solid #ccc",
        //         display: "flex",
        //         alignItems: "center",
        //         justifyContent: "center",
        //       }}
        //     >
        //       <Typography variant="body1" style={{ color: "blue" }}>
        //         {renderBitRepresentation(secondBlockPadding)}
        //       </Typography>
        //     </Paper>
        //   </Grid>
        //   <Grid item xs={2}>
        //     <Typography
        //       variant="subtitle1"
        //       style={{ color: "red", textAlign: "center" }}
        //     >
        //       Length of Input{" "}
        //     </Typography>
        //     <Paper
        //       elevation={3}
        //       style={{
        //         borderRadius: "5px",
        //         backgroundColor: "#f0f0f0",
        //         height: "70px",
        //         border: "1px solid #ccc",
        //         display: "flex",
        //         alignItems: "center",
        //         justifyContent: "center",
        //       }}
        //     >
        //       <Typography variant="body1" style={{ color: "red" }}>
        //         {secondBlockLength}
        //       </Typography>
        //     </Paper>
        //   </Grid>
        //   <Grid item xs={6} style={{ textAlign: "center" }}>
        //     <Typography
        //       variant="subtitle1"
        //       style={{ color: "black", marginTop: "10px" }}
        //     >
        //       <IconButton>
        //         <ArrowBack />
        //       </IconButton>
        //       <span style={{ marginLeft: "10px", marginRight: "10px" }}>
        //         {" "}
        //         512 Bits Block
        //       </span>
        //       <IconButton>
        //         <ArrowForward />
        //       </IconButton>
        //     </Typography>
        //   </Grid>
        // </>
  //     );
  //   }
  //   return null;
  // };

  return (
    <>
      {!showFinalStep && (
        <>
        {text.length<56 &&
         <div
         style={{
           display: "flex",
           justifyContent: "center",
           alignItems: "center",
           height: "100vh",
         }}
       >
         <div style={{ whiteSpace: "nowrap", padding: "5px" }}>
           <Typography
             variant="h5"
             gutterBottom
             align="center"
             style={{ margin: "20px", marginBottom: "50px" }}
           >
             Message Padding
           </Typography>
           <Grid container spacing={2}>
             <Grid item xs={ 4}>
               <Typography
                 variant="subtitle1"
                 style={{ color: "grey", textAlign: "center" }}
               >
                 Original Message Bit{" "}
               </Typography>
               <Paper
                 elevation={3}
                 style={{
                   borderRadius: "5px",
                   backgroundColor: "#f0f0f0",
                   height: "70px",
                   border: "1px solid #ccc",
                   display: "flex",
                   alignItems: "center",
                   justifyContent: "center",
                 }}
               >
                 <Typography variant="body1" style={{ color: "grey" }}>
                   {renderBitRepresentation(output.slice(0, 448))}
                 </Typography>
               </Paper>
             </Grid>
             {text.length <= 64 && (
               <Grid item xs={4}>
                 <Typography
                   variant="subtitle1"
                   style={{ color: "blue", textAlign: "center" }}
                 >
                   Padding Bits
                 </Typography>
                 <Paper
                   elevation={3}
                   style={{
                     borderRadius: "5px",
                     backgroundColor: "#f0f0f0",
                     height: "70px",
                     border: "1px solid #ccc",
                     display: "flex",
                     alignItems: "center",
                     justifyContent: "center",
                   }}
                 >
                   {text.length > 0 && (
                     <Typography variant="body1" style={{ color: "blue" }}>
                       10000......00000
                     </Typography>
                   )}
                 </Paper>
               </Grid>
             )}
             {text.length > 64 && (
               <Grid item xs={4}>
                 <Typography
                   variant="subtitle1"
                   style={{ color: "blue", textAlign: "center" }}
                 >
                   Padding Bits
                 </Typography>
                 <Paper
                   elevation={3}
                   style={{
                     borderRadius: "5px",
                     backgroundColor: "#f0f0f0",
                     height: "70px",
                     border: "1px solid #ccc",
                     display: "flex",
                     alignItems: "center",
                     justifyContent: "center",
                   }}
                 >
                   <Typography variant="body1" style={{ color: "blue" }}>
                     no padding bits
                   </Typography>
                 </Paper>
               </Grid>
             )}
             <Grid item xs={4}>
               <Typography
                 variant="subtitle1"
                 style={{ color: "red", textAlign: "center" }}
               >
                 Length of Input
               </Typography>
               <Paper
                 elevation={3}
                 style={{
                   borderRadius: "5px",
                   backgroundColor: "#f0f0f0",
                   height: "70px",
                   border: "1px solid #ccc",
                   display: "flex",
                   alignItems: "center",
                   justifyContent: "center",
                 }}
               >
                 <Typography variant="body1" style={{ color: "red" }}>
                   {renderBitRepresentation(output.slice(output.length - 64))}
                 </Typography>
               </Paper>
             </Grid>
            
             <Grid
               item
               xs={text.length > 64 ? 6 : 12}
               style={{ textAlign: "center" }}
             >
               <Typography
                 variant="subtitle1"
                 style={{ color: "black", marginTop: "10px" }}
               >
                 <IconButton>
                   <ArrowBack />
                 </IconButton>
                 <span style={{ marginLeft: "10px", marginRight: "10px" }}>
                   {" "}
                   512 Bits Block
                 </span>
                 <IconButton>
                   <ArrowForward />
                 </IconButton>
               </Typography>
             </Grid>
           </Grid>
           {text.length > 0 && <BoxComponent />}
           <Grid
             item
             xs={12}
             style={{ textAlign: "right", marginLeft: "-40px" }}
           >
             <IconButton color="primary" onClick={handleNextClick}>
               Next
               <ArrowForward />
             </IconButton>
           </Grid>
         </div>
         
       </div>
       }{text.length>=56 &&
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <div style={{ whiteSpace: "nowrap", padding: "10px" }}>
            <Typography
              variant="h5"
              gutterBottom
              align="center"
              style={{ margin: "20px", marginBottom: "50px" }}
            >
              Message Padding
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={ 2}>
                <Typography
                  variant="subtitle1"
                  style={{ color: "grey", textAlign: "center" }}
                >
                  Original Message Bit{" "}
                </Typography>
                <Paper
                  elevation={3}
                  style={{
                    borderRadius: "5px",
                    backgroundColor: "#f0f0f0",
                    height: "70px",
                    border: "1px solid #ccc",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Typography variant="body1" style={{ color: "grey" }}>
                    {renderBitRepresentation(output.slice(0, 448))}
                  </Typography>
                </Paper>
              </Grid>
              {/* {text.length <= 64 && (
                <Grid item xs={3}>
                  <Typography
                    variant="subtitle1"
                    style={{ color: "blue", textAlign: "center" }}
                  >
                    Padding Bits
                  </Typography>
                  <Paper
                    elevation={3}
                    style={{
                      borderRadius: "5px",
                      backgroundColor: "#f0f0f0",
                      height: "70px",
                      border: "1px solid #ccc",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {text.length > 0 && (
                      <Typography variant="body1" style={{ color: "blue" }}>
                        10000......00000
                      </Typography>
                    )}
                  </Paper>
                </Grid>
              )} */}
              {text.length > 56 && (
                <Grid item xs={2}>
                  <Typography
                    variant="subtitle1"
                    style={{ color: "blue", textAlign: "center" }}
                  >
                    Padding Bits
                  </Typography>
                  <Paper
                    elevation={2}
                    style={{
                      borderRadius: "5px",
                      backgroundColor: "#f0f0f0",
                      height: "70px",
                      border: "1px solid #ccc",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Typography variant="body1" style={{ color: "blue" }}>
                      no padding bits
                    </Typography>
                  </Paper>
                </Grid>
              )}
              <Grid item xs={2}>
                <Typography
                  variant="subtitle1"
                  style={{ color: "red", textAlign: "center" }}
                >
                  Length of Input
                </Typography>
                <Paper
                  elevation={2}
                  style={{
                    borderRadius: "5px",
                    backgroundColor: "#f0f0f0",
                    height: "70px",
                    border: "1px solid #ccc",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Typography variant="body1" style={{ color: "red" }}>
                    {renderBitRepresentation(output.slice(output.length - 64))}
                  </Typography>
                </Paper>
              </Grid>
              <Grid item xs={ 2}>
                <Typography
                  variant="subtitle1"
                  style={{ color: "grey", textAlign: "center" }}
                >
                  Original Message Bit{" "}
                </Typography>
                <Paper
                  elevation={3}
                  style={{
                    borderRadius: "5px",
                    backgroundColor: "#f0f0f0",
                    height: "70px",
                    border: "1px solid #ccc",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Typography variant="body1" style={{ color: "grey" }}>
                    {renderBitRepresentation(output.slice(0, 448))}
                  </Typography>
                </Paper>
              </Grid>
               {text.length <= 64 && (
                <Grid item xs={2}>
                  <Typography
                    variant="subtitle1"
                    style={{ color: "blue", textAlign: "center" }}
                  >
                    Padding Bits
                  </Typography>
                  <Paper
                    elevation={3}
                    style={{
                      borderRadius: "5px",
                      backgroundColor: "#f0f0f0",
                      height: "70px",
                      border: "1px solid #ccc",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {text.length > 0 && (
                      <Typography variant="body1" style={{ color: "blue" }}>
                        10000......00000
                      </Typography>
                    )}
                  </Paper>
                </Grid>
              )}
               <Grid item xs={ 2}>
                <Typography
                  variant="subtitle1"
                  style={{ color: "grey", textAlign: "center" }}
                >
                  Original Message Bit{" "}
                </Typography>
                <Paper
                  elevation={3}
                  style={{
                    borderRadius: "5px",
                    backgroundColor: "#f0f0f0",
                    height: "70px",
                    border: "1px solid #ccc",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Typography variant="body1" style={{ color: "grey" }}>
                    {renderBitRepresentation(output.slice(0, 448))}
                  </Typography>
                </Paper>
              </Grid>
              <Grid
                item
                xs={text.length > 64 ? 6 : 12}
                style={{ textAlign: "center" }}
              >
                <Typography
                  variant="subtitle1"
                  style={{ color: "black", marginTop: "10px" }}
                >
                  <IconButton>
                    <ArrowBack />
                  </IconButton>
                  <span style={{ marginLeft: "10px", marginRight: "10px" }}>
                    {" "}
                    512 Bits Block
                  </span>
                  <IconButton>
                    <ArrowForward />
                  </IconButton>
                </Typography>
              </Grid>
              <Grid item xs={2}>
                <Typography
                  variant="subtitle1"
                  style={{ color: "red", textAlign: "center" }}
                >
                  Length of Input
                </Typography>
                <Paper
                  elevation={2}
                  style={{
                    borderRadius: "5px",
                    backgroundColor: "#f0f0f0",
                    height: "70px",
                    border: "1px solid #ccc",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Typography variant="body1" style={{ color: "red" }}>
                    {renderBitRepresentation(output.slice(output.length - 64))}
                  </Typography>
                </Paper>
              </Grid>
            </Grid>
            {text.length > 0 && <BoxComponent />}
            <Grid
              item
              xs={12}
              style={{ textAlign: "right", marginLeft: "-40px" }}
            >
              <IconButton color="primary" onClick={handleNextClick}>
                Next
                <ArrowForward />
              </IconButton>
            </Grid>
          </div>
          
        </div>}
        </>
       
      )}
      
    <div>{showFinalStep && <FinalStep />}</div>
    </>
  );
};

const mapStateToProps = (state) => ({
  text: state.text,
});

export default connect(mapStateToProps)(MessagePadding);
