import React, { useState } from "react";
import { Button } from "@mui/material";
import Svg from "./Box";
import { updateDetailText } from "../redux/inputReducer";
import { useDispatch, useSelector } from "react-redux";
import md5 from "md5";
import { PuffLoader } from "react-spinners";

const ClickArrow = () => (
  <>
  <span
    style={{
      marginLeft: "5px",
    display: "inline-block",
    width: "10px",
    height: "10px",
    borderLeft: "2px solid black",
    borderBottom: "2px solid black",
    transform: "rotate(45deg)",
    animation: "blink 1s infinite",
    }}
  />
  <span style={{text:'red'}}>Click here</span>
  </>
);

const FinalStep = () => {
  const [step, setStep] = useState(0);
  const [md5Hash, setMd5Hash] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showFinalMessage, setShowFinalMessage] = useState(false);
  const dispatch = useDispatch();
  const { text } = useSelector((state) => state.md);
  const detailTexts = [
    "Initialization: A, B, C, and D are 32-bit buffer variables initialized with specific constant values in the MD5 algorithm. The entire message is first divided into 512-bit chunks. Each chunk consists of 16 words, where each word is 32 bits long.",
    "Add Function: Each round utilizes a different non-linear mathematical function. These functions are designed to be complex and unpredictable, making it difficult to predict the outcome based solely on the input message.",
    "Add Buffer A: Add buffer A to the state",
    "Add Sub-Blocks: Divide the message into 512-bit sub-blocks.Add to it",
    "Add Constants: Add constants derived from the sine function",
    "Circular Shift: Perform circular left shifts on the buffer",
    "Buffer Update: Update the buffer based on the sub-block",
    "Store in Buffer B: Store the result in buffer B",
    "Buffer Shift: Shift the buffer for the next iteration. This completes one cycle. This process will continue 16 times for each non linear function.",
  ];

  const handleStepClick = (stepNumber, detail) => {
    if (stepNumber === step + 1) {
      setStep(stepNumber);
      dispatch(updateDetailText(detail));
    }
  };

  const calculateMD5 = () => {
    setLoading(true);
    setTimeout(() => {
      const hash = md5(text);
      setMd5Hash(hash);
      setLoading(false);
      setShowFinalMessage(true); 
    }, 2000);
  };

  const buttonStyle = {
    margin: "5px",
    backgroundColor: "blue",
    color: "white",
    width: "60%",
    padding: "5px",
    justifyContent: "center",
    display: "flex",
  };

  return (
    <div>
      <div style={{ justifyContent: "center", display: "flex" }}>
        <h2 style={{ alignContent: "center", margin: "20px" }}>
          Message Chunk Processing
        </h2>
      </div>
      <div className="row">
        <div
          className="col-md-3"
          style={{ alignContent: "center", padding: "5px" }}
        >
          {detailTexts.map((detail, index) => (
            <div key={index} style={{ display: "flex", alignItems: "center" }}>
              <Button
                style={{
                  ...buttonStyle,
                  backgroundColor:
                    step === index + 1
                      ? "green"
                      : step !== index
                      ? "gray"
                      : "blue",
                  position: "relative", // Add this style for positioning
                }}
                variant="outlined"
                onClick={() => handleStepClick(index + 1, detail)}
              >
                {detail.split(":")[0]}
              </Button>
              {step === index && ( // Render arrow only for the active step
                <ClickArrow /> 
              )}
            </div>
          ))}
        </div>
        <div className="col-md-9">
          <Svg step={step} />

          {step === detailTexts.length && (
            <div style={{ display: "flex", alignItems: "center" }}>
              <Button
                style={{ backgroundColor: "blue", color: "white" }}
                variant="outlined"
                onClick={calculateMD5}
                disabled={loading}
              >
                Show MD5 Hash Value
              </Button>
              <div style={{ marginLeft: "10px" }}>
                {loading ? (
                  <PuffLoader color={"blue"} loading={loading} size={50} />
                ) : (
                  md5Hash && <div>{md5Hash}</div>
                )}
              </div>
            </div>
          )}

          {showFinalMessage && (
            <div style={{ marginTop: "20px", color: "green" }}>
              The MD5 hashing process is complete. Your hashed value is displayed above.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FinalStep;
