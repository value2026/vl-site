import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { updateText } from "../redux/inputReducer";
import MessagePadding from "./Padding";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faInfoCircle } from "@fortawesome/free-solid-svg-icons";

const Step1 = () => {
  const dispatch = useDispatch();
  const [inputText, setInputText] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [showMessage, setShowMessage] = useState(false); 
  const { detailText } = useSelector((state) => state.md);

  useEffect(() => {
    if (showMessage) {
      const timeout = setTimeout(() => {
        setShowMessage(false);
      }, 7000); 
      return () => clearTimeout(timeout);
    }
  }, [showMessage]);

  const handleChange = (e) => {
    setInputText(e.target.value.slice(0, 120));
  };

  const handleSubmit = () => {
    dispatch(updateText(inputText));
    setSubmitted(true);
    setShowMessage(true);
  };

  return (
    <div className="container-fluid">
      <div className="row">
        <div
          className="col-md-2"
          style={{
            backgroundColor: "#333333",
            height: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "flex-start",
          }}
        >
          <div
            style={{
              backgroundColor: "#555555",
              color: "white",
              padding: "10px",
              borderRadius: "5px",
              width: "200px",
              textAlign: "center",
              marginTop: "20px",
            }}
          >
            <h4 style={{ margin: "0" }}>Hashing </h4>
            <p style={{ margin: "10px 0", lineHeight: "1.4" }}>
              Hashing is a process that transforms input data of any size into a fixed-size value, typically used for indexing and quick data retrieval.
            </p>
          </div>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              flexGrow: 1,
            }}
          >
            {detailText && (
              <div>
                <p style={{ color: 'white' }}>{detailText}</p>
              </div>
            )}
            {!submitted && (
              <div style={{ width: "80%" }}>
                <div
                  style={{
                    marginBottom: "20px",
                  }}
                ></div>
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: "#333333",
                    color: "white",
                    padding: "10px",
                    borderRadius: "5px",
                    width: "120%",
                  }}
                >
                  <div style={{ marginBottom: "10px" }}>Enter your Text</div>
                  <input
                    type="text"
                    className="form-control"
                    style={{
                      backgroundColor: "#3CA4AB",
                      color: "white",
                      border: "1px solid #cccccc",
                      marginBottom: "10px",
                      width: "100%",
                    }}
                    value={inputText}
                    onChange={handleChange}
                    maxLength={200}
                  />
                  <button
                    type="submit"
                    className="btn btn-primary"
                    style={{
                      backgroundColor: "#3CA4AB",
                      color: "white",
                      border: "1px solid #cccccc",
                      width: "100%",
                    }}
                    onClick={handleSubmit}
                  >
                    Generate
                  </button>
                </div>
              </div>
            )}
            {showMessage && (
              <div
                style={{
                  marginTop: "10px",
                  color: "white",
                  textAlign: "center",
                  backgroundColor: "#3CA4AB",
                  padding: "10px",
                  borderRadius: "5px",
                  boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.1)",
                  animation: "fadeInOut 7s ease-in-out",
                }}
              >
                <FontAwesomeIcon icon={faInfoCircle} style={{ marginRight: "10px" }} />
                <span>Your input message has been received. The MD5 hashing process is underway. Please wait as we guide you through each step.</span>
              </div>
            )}
          </div>
        </div>
        <div
          className="col-md-10"
          style={{ backgroundColor: "#3CA4AB", height: "100vh" }}
        >
          <MessagePadding />
        </div>
      </div>
    </div>
  );
};

export default Step1;
