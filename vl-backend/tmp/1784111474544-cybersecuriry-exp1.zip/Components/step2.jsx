import React, { useRef, useState } from "react";
import { useSelector } from "react-redux";
import { Canvas } from "@react-three/fiber";
import { Box, Html, Text } from "@react-three/drei";
import { useSpring, animated } from "@react-spring/three";
import { Suspense } from "react";


const BoxComponent = () => {
  const { text } = useSelector((state) => state.md);
  const [hovered, setHovered] = useState(false);
  const [hasHovered, setHasHovered] = useState(false); // New state variable to track if the box has been hovered
  const textLength = text ? text.length : 0;
  const textSizeInBits = text ? text.length * 8 : 0;
  const paddingBits =
    textSizeInBits > 448 ? 448 - (textSizeInBits - 512) : 448 - textSizeInBits;
  const showTwoBoxes = textSizeInBits > 448;

  const springProps = useSpring({
    scale: hovered ? [1.5, 1.5, 1.5] : [1, 1, 1],
    color: hovered ? "hotpink" : "orange",
  });

  const handlePointerOver = () => {
    setHovered(true);
    setHasHovered(true); // Set hasHovered to true when the box is hovered for the first time
  };

  return (
    <center>
      <div className="canvas-container">
        <Canvas style={{ height: "200px", width: "300px" }}>
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} />
          <Suspense
            fallback={
              <Html>
                <div>Loading...</div>
              </Html>
            }
          >
            {showTwoBoxes ? (
              <>
                <animated.mesh
                  position={[-1, 0, 0]}
                  scale={springProps.scale}
                  onPointerOver={handlePointerOver}
                  onPointerOut={() => setHovered(false)}
                >
                  <boxGeometry args={[1.5, 1.5, 1.5]} />
                  <animated.meshStandardMaterial color={springProps.color} />
                </animated.mesh>
                <animated.mesh
                  position={[3, 0, 0]}
                  scale={springProps.scale}
                  onPointerOver={handlePointerOver}
                  onPointerOut={() => setHovered(false)}
                >
                  <boxGeometry args={[1.5, 1.5, 1.5]} />
                  <animated.meshStandardMaterial color={springProps.color} />
                  {hovered && (
                    <>
                      <Text
                        position={[-2.6, 0, 1]}
                        fontSize={0.3}
                        color="black"
                        anchorX="center"
                        anchorY="middle"
                      >
                        512 Bits
                      </Text>
                      <Text
                        position={[-0.3, 0, 1]}
                        fontSize={0.3}
                        color="black"
                        anchorX="center"
                        anchorY="middle"
                      >
                        512 Bits
                      </Text>
                      <Text
                        position={[-1.5, -1.2, 0.5]}
                        fontSize={0.3}
                        color="black"
                        anchorX="center"
                        anchorY="middle"
                      >
                        Number of Characters: {textLength}
                      </Text>
                      <Text
                        position={[-1.5, -1.6, 0.5]}
                        fontSize={0.3}
                        color="black"
                        anchorX="center"
                        anchorY="middle"
                      >
                        Number of Input Text Bits: {textSizeInBits}
                      </Text>
                      <Text
                        position={[-1.5, -2, 0.5]}
                        fontSize={0.3}
                        color="black"
                        anchorX="center"
                        anchorY="middle"
                      >
                        Number of Padding Bits: {paddingBits}
                      </Text>
                    </>
                  )}
                </animated.mesh>
              </>
            ) : (
              <animated.mesh
                position={[0, 0, 0]}
                scale={springProps.scale}
                onPointerOver={handlePointerOver}
                onPointerOut={() => setHovered(false)}
              >
                <boxGeometry args={[1.5, 1.5, 1.5]} />
                <animated.meshStandardMaterial color={springProps.color} />

                {hovered && (
                  <>
                    <Text
                      position={[0, 0, 1]}
                      fontSize={0.3}
                      color="black"
                      anchorX="center"
                      anchorY="middle"
                    >
                      512 Bits
                    </Text>
                    <Text
                      position={[0.5, -1.2, 0.5]}
                      fontSize={0.3}
                      color="black"
                      anchorX="center"
                      anchorY="middle"
                    >
                      Number of Characters: {textLength}
                    </Text>
                    <Text
                      position={[0.5, -1.6, 0.5]}
                      fontSize={0.3}
                      color="black"
                      anchorX="center"
                      anchorY="middle"
                    >
                      Number of Input Text Bits: {textSizeInBits}
                    </Text>
                    <Text
                      position={[0.5, -2, 0.5]}
                      fontSize={0.3}
                      color="black"
                      anchorX="center"
                      anchorY="middle"
                    >
                      Number of Padding Bits: {paddingBits}
                    </Text>
                  </>
                )}
              </animated.mesh>
            )}
          </Suspense>
        </Canvas>
        {!hasHovered && <div className="blinking-text">Hover the box</div>}
      </div>
    </center>
  );
};

export default BoxComponent;
