
import { configureStore } from "@reduxjs/toolkit";

import mdReducer from './inputReducer'
const store = configureStore({
    reducer: {
        md: mdReducer
    }
})
export default store