import { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Physics } from "@react-three/cannon";
import { Canvas } from "@react-three/fiber";
import "./App.css";
import Step1 from "./Components/step1";
import store from "./redux/store";
import { Provider } from "react-redux";

function App() {
  return (
    <>
      <Provider store={store}>
        <Step1 />
      </Provider>
    </>
  );
}

export default App;
