import React from 'react';
import styled from 'styled-components';

const DisassemblyContainer = styled.div`
  background-color: black;
  color: green;
  font-family: monospace;
  padding: 10px;
  border: 1px solid green;
  margin-bottom: 10px;
`;

const Disassembly = () => (
  <DisassemblyContainer>
  
    <p>0x00177ff8: mov rbx, rbp</p>
    <p>0x00177ffc: mov rbx, rsp</p>
    <p>0x00178000: call 0x178c0</p>
    <p>0x00178004: add rsp, 0x10</p>
    <p>0x00178008: ret</p>
  </DisassemblyContainer>
);

export default Disassembly;
