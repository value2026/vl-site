import React from 'react';
import { useSelector } from 'react-redux';
import styled from 'styled-components';
import Stack from './Stacks';
import Registers from './Register';
import Disassembly from './Dessembly';

const OverflowContainer = styled.div`
  background-color: black;
  color: green;
  font-family: monospace;
  padding: 10px;
  border: 1px solid green;
`;

const HorizontalContainer = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
`;

const BufferOverflow = () => {
  const { text } = useSelector((state) => state.md);
  const bufferSize = 8;
  const stackSize = 3; // Adjust stack size for simplicity
  const baseAddress = 0x00178000; // Adjust base address for alignment
  const addressStep = 0x8;

  const stack = Array(stackSize).fill(null).map((_, index) => ({
    address: baseAddress + index * addressStep,
    data: '0000000000000000'
  }));

  let overflowStack = [...stack];
  let isOverflow = text.length > bufferSize;
  let newRip = '0x0000000000000000';

  if (isOverflow) {
    const overflowData = text.slice(bufferSize);
    overflowStack = overflowStack.map((row, index) => {
      if (index === 0) {
        return { ...row, data: text.slice(0, bufferSize).padEnd(bufferSize, '\0') };
      }
      if (index === 1) {
        newRip = `0x${overflowData.padEnd(16, '0').slice(0, 16)}`;
        return { ...row, data: overflowData.padEnd(bufferSize, '\0').slice(0, bufferSize) };
      }
      return row;
    });
  } else {
    overflowStack[0] = { ...stack[0], data: text.padEnd(bufferSize, '\0') };
  }

  return (
    <OverflowContainer>
      {/* <h2 style={{ color: 'cyan' }}>Buffer Overflow Simulation</h2>
      <p>Input Text: {text}</p> */}
      <HorizontalContainer>
        <Registers newRip={newRip} isOverflow={isOverflow} />
        <Disassembly />
      </HorizontalContainer>
      <p>Stack:</p>
      <Stack stack={overflowStack} isOverflow={isOverflow} />
    </OverflowContainer>
  );
};

export default BufferOverflow;
