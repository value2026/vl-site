import React from 'react';
import { useSelector } from 'react-redux';
import styled, { keyframes } from 'styled-components';
import BufferOverflow from './BufferOverFlow';

const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  background-color: black;
  padding: 20px;
  color: white;
  font-family: Arial, sans-serif;
`;

const fadeIn = keyframes`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`;

const AnimatedText = styled.p`
  animation: ${fadeIn} 2s ease-in-out;
  color: white;
  background-color: #333;
  padding: 15px;
  border-radius: 5px;
  border: 1px solid #555;
  text-align: center;
  margin-top: 20px;
  font-size: 16px;
  line-height: 1.5;
`;

const App = () => {
  const { text } = useSelector((state) => state.md);

  return (
    <>
      <AppContainer>
        <BufferOverflow />
      </AppContainer>
      <AnimatedText>
        In this stack view of buffer overflow, the entered input exceeds the 8-character buffer limit, causing it to overflow and overwrite the address, resulting in a change of the RIP address.
      </AnimatedText>
    </>
  );
};

export default App;
