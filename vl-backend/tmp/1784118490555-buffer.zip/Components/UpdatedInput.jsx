import React, { useState, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { updateText } from "../redux/InputReducer";

const bufferOverflowContent = [
  {
    title: "What is a buffer?",
    content: "A buffer is a temporary storage area typically used to hold data while it is being transferred from one place to another. Buffers are used in many aspects of programming and hardware to handle data more efficiently."
  },
  {
    title: "What is saved EBP?",
    content: "Saved EBP (Base Pointer) is a register that holds the base address of the stack frame. It helps in accessing function parameters and local variables within a stack frame. During a buffer overflow, the saved EBP can be overwritten, which can lead to control flow hijacking."
  },
  {
    title: "What is saved EIP?",
    content: "Saved EIP (Instruction Pointer) is a register that holds the address of the next instruction to be executed. In the context of buffer overflow, attackers often aim to overwrite the saved EIP to redirect the execution flow to malicious code."
  },
  {
    title: "How does buffer overflow occur?",
    content: "Buffer overflow occurs when data exceeds the buffer's storage capacity, causing data to overwrite adjacent memory. This can lead to unexpected behavior, crashes, or even the execution of malicious code."
  },
  {
    title: "Why is buffer overflow dangerous?",
    content: "Buffer overflow is dangerous because it can allow attackers to execute arbitrary code, gain unauthorized access, or crash a system. It exploits a vulnerability in the code, making it a common target for attacks."
  },
  {
    title: "How to prevent buffer overflow?",
    content: "To prevent buffer overflow, ensure proper bounds checking, use safe functions that limit the amount of data written to a buffer, and employ modern programming languages or compiler options that include built-in protections."
  },
  {
    title: "What is little-endian?",
    content: "In little-endian format, the least significant byte (the 'little end') is stored first. For example, the hexadecimal value 0x17805018 is stored in memory as 0x18, 0x50, 0x80, 0x17. This is important for correctly exploiting the buffer overflow to ensure the win function address is interpreted correctly."
  }
];

const UpdatedInput = ({ onGenerate }) => {
  const dispatch = useDispatch();
  const text = useSelector((state) => state.md.text); // Get the text from Redux state

  const [errorMessage, setErrorMessage] = useState("");
  const [showMessage, setShowMessage] = useState(false);
  const [openAccordion, setOpenAccordion] = useState(null);
const lastSubmitClickRef = useRef(null); // Add this at the top inside your component

const handleGenerateClicks = () => {
  const clickDetail = "submit_button_clicked";

  // Prevent sending the same click event twice
  if (lastSubmitClickRef.current !== clickDetail) {
    window.parent.postMessage(
      {
        type: "SIM_CLICK",
        detail: clickDetail,
      },
      "*"
    );
    lastSubmitClickRef.current = clickDetail;
  }

  if (text.length <= 0) {
    setErrorMessage("Please enter some text before submitting.");
  } else {
    dispatch(updateText(text));
    setErrorMessage("");
    onGenerate();
    setShowMessage(true);

    // ✅ Send simulation progress message to parent
    window.parent.postMessage(
      {
        type: "simulationProgress",
        step: "step-buffer-submit",
      },
      "*"
    );
  }
};



  const toggleAccordion = (index) => {
    setOpenAccordion(openAccordion === index ? null : index);
  };

  return (
    <div
      style={{
        backgroundColor: "#3CA4AB",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "20px",
        boxSizing: "border-box",
      }}
    >
      <div
        style={{
          color: "white",
          padding: "10px",
          borderRadius: "5px",
          textAlign: "center",
          marginTop: "20px",
        }}
      >
        <h4 style={{ margin: "0" }}>Buffer Overflow</h4>
      </div>

      {/* Scrollable Accordion Section */}
      <div
        style={{
          width: "80%",
          marginTop: "20px",
          height: "150px", // Adjust to show ~3 items
          overflowY: "auto",
          overflowX: "hidden",
        }}
      >
        {bufferOverflowContent.map((accordion, index) => (
          <div
            key={index}
            style={{
              marginBottom: "10px",
              borderRadius: "5px",
              backgroundColor: "#2A8C94",
              padding: "10px",
              cursor: "pointer",
              transition: "background-color 0.3s",
              boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
            }}
            onClick={() => toggleAccordion(index)}
          >
            <div style={{ fontWeight: "bold", color: "white" }}>
              {accordion.title}
            </div>
            {openAccordion === index && (
              <div style={{ marginTop: "10px", color: "white" }}>
                {accordion.content}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Input and Submit Section - Vertically Centered */}
      <div
        style={{
          width: "80%",
          marginTop: "20px",
          marginBottom: "20px",
          flexGrow: 1, // Takes available space
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center", // Center contents vertically
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            backgroundColor: "#3CA4AB",
            color: "white",
            borderRadius: "5px",
            width: "100%",
            padding: "20px", // Increased padding for better spacing
          }}
        >
          <div style={{ marginBottom: "10px" }}>Your Text</div>
          <input
            type="text"
            className="form-control"
            style={{
              backgroundColor: "#3CA4AB",
              color: "white",
              border: "1px solid #cccccc",
              marginBottom: "15px", // Adjusted spacing
              width: "100%",
              padding: "10px",
              borderRadius: "5px",
            }}
            value={text}
            readOnly
          />
          {errorMessage && (
            <div style={{ color: "red", marginBottom: "15px" }}>
              {errorMessage}
            </div>
          )}
          <button
            type="button"
            className="btn btn-primary"
            style={{
              backgroundColor: "#2A8C94",
              color: "white",
              border: "1px solid #cccccc",
              width: "100%",
              padding: "10px",
              borderRadius: "5px",
            }}
            onClick={handleGenerateClicks}
          >
            Submit
          </button>
        </div>
        {showMessage && (
          <div
            style={{
              marginTop: "10px",
              color: "white",
              textAlign: "center",
              backgroundColor: "#3CA4AB",
              padding: "10px",
              borderRadius: "5px",
              boxShadow: "0px 0px 10px rgba(0, 0, 0, 0.1)",
              animation: "fadeInOut 7s ease-in-out",
            }}
          >
            <span>
              Your input has been safely processed! The buffer was filled
              without any overflow, demonstrating that the code is now
              secure against buffer overflow attacks
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default UpdatedInput;