import React, { useState } from 'react';
import WarningDialog from './WarningDialog';

const Warning = () => {
  const [showWarning, setShowWarning] = useState(true);

  

  const handleCloseWarning = () => {
    setShowWarning(false);
  };

  return (
    <div style={{marginTop:'50px'}}>
      
      {showWarning && (
        <WarningDialog
          message="A buffer overrun has been detected which has corrupted the program's internal state. The program cannot safely continue execution and must now be terminated."
          onClose={handleCloseWarning}
        />
      )}
    </div>
  );
};

export default Warning;
