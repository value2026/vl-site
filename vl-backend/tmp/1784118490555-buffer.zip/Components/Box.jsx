import React from "react";

const Box = ({ position, color }) => {
  return (
    <mesh position={position} rotation={ [0, 0, 0]}>
      <boxGeometry args={[.7, .7, 1.5]} />
      <meshStandardMaterial color={color}  />
    </mesh>
  );
};

export default Box;
