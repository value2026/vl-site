import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

const BufferOverflowVisualization = () => {
  const { text } = useSelector((state) => state.md);
  const bufferSize = 16; // 4 columns x 4 rows
  const ebpSize = 4;
  const eipSize = 4;
  const totalSize = bufferSize + ebpSize + eipSize;
  const [warningMessage, setWarningMessage] = useState('');
  const savedEbp = ['43', 'd3', 'f9', '81']; // Fixed EBP value

  useEffect(() => {
    if (text.length > bufferSize) {
      setWarningMessage('Warning: The buffer is not overflowing, but input longer than 16 characters may cause incorrect behavior.');
    } else {
      setWarningMessage('');
    }
  }, [text]);

  const getCellColor = (index) => {
    if (index >= bufferSize + ebpSize) return '#FF6347'; // Color for EIP
    if (index >= bufferSize) return '#FFD700'; // Color for EBP
    return '#61AFEF'; // Color for buffer
  };

  const values = Array.from({ length: totalSize }, (_, i) => {
    if (i >= text.length) {
      // Use fixed saved EBP values
      if (i >= bufferSize && i < bufferSize + ebpSize) {
        return savedEbp[i - bufferSize];
      }
      return '00'; // Default value if no input
    }

    const charCode = text.charCodeAt(i);
    return isNaN(charCode) ? '00' : charCode.toString(16).padStart(2, '0');
  }).reverse();

  const bufferValues = values.slice(eipSize + ebpSize, eipSize + ebpSize + bufferSize);

  return (
    <div className="visualization-container">
      <div className="memory-container">
        <div className="eip-grid">
          {Array.from({ length: eipSize }, (_, i) => (
            <div
              key={i}
              className="buffer-cell"
              style={{ backgroundColor: getCellColor(bufferSize + ebpSize + i) }}
            >
              00
            </div>
          ))}
        </div>
        <div className="label">Saved EIP</div>
        <div className="ebp-grid">
          {Array.from({ length: ebpSize }, (_, i) => (
            <div
              key={i}
              className="buffer-cell"
              style={{ backgroundColor: getCellColor(bufferSize + i) }}
            >
              {savedEbp[i] || '00'}
            </div>
          ))}
        </div>
        <div className="label">Saved EBP</div>
        <div className="buffer-grid">
          {bufferValues.map((value, i) => (
            <div
              key={i}
              className="buffer-cell"
              style={{ backgroundColor: getCellColor(i) }}
            >
              {value}
            </div>
          ))}
        </div>
        <div className="label">Buffer</div>
        <div className="arrow-container">
          <div className="arrow"></div>
        </div>
      </div>
      {warningMessage && <div className="warning">{warningMessage}</div>}
    </div>
  );
};

export default BufferOverflowVisualization;
