
import { Light as SyntaxHighlighter } from "react-syntax-highlighter";
import { docco } from "react-syntax-highlighter/dist/esm/styles/hljs";
import React, { useState, useRef } from "react";

const vulnerableCode = `#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void win() {
    FILE *flag;
    char flag_content[16];
    
    flag = fopen("flag.txt", "r");
    if (flag == NULL) {
        printf("Flag not found\\n");
        return;
    }

    fgets(flag_content, sizeof(flag_content),
     flag);
    printf("Flag: %s\\n", flag_content);
    fclose(flag);
}

void vuln() {
    char buffer[8];
    setvbuf(stdout, NULL, _IONBF,0);
    printf("Enter your input: ");
    gets(buffer); 
    printf("you entered: %s\\n", buffer);
}

int main() {
    vuln();
    return 0;
}`;

const correctCodeFragment = `if (fgets(buffer, sizeof(buffer), stdin) != NULL)`;
const options = [
  `gets(input);`,
  `if (fgets(buffer, sizeof(buffer), stdin) != NULL)`,
];

const correctedCodeBefore = `#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void win() {
    FILE *flag;
    char flag_content[8];

    flag = fopen("flag.txt", "r");
    if (flag == NULL) {
        printf("Flag not found\\n");
        return;
    }

    fgets(flag_content, sizeof(flag_content), 
    flag);
    printf("Flag: %s\\n", flag_content);
    fclose(flag);
}

void vuln() {
    char buffer[8];
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("Enter your input: ");
`;

const highlightLine = `    if (fgets(buffer, sizeof(buffer), stdin) != NULL)`;

const correctedCodeAfter = `{
        buffer[strcspn(buffer, "\\n")] = '\\0'; 
        printf("you entered: %s\\n", buffer);
    }
}

int main() {
    vuln();
    return 0;
}`;

function Code({ setIsCorrect, setShowBuffer }) {
  const [selectedOption, setSelectedOption] = useState(options[0]);
  const [feedback, setFeedback] = useState("");
  const [isCorrectLocal, setIsCorrectLocal] = useState(false);

  const lastClickRef = useRef(null); // Add this at the top inside your component

const checkCode = () => {
  const clickDetail = "check_code_button_clicked";

  // ✅ Avoid sending duplicate event if last was same
  if (lastClickRef.current !== clickDetail) {
    window.parent.postMessage(
      {
        type: "SIM_CLICK",
        detail: clickDetail,
      },
      "*"
    );
    lastClickRef.current = clickDetail;
  }

  const correctTrimmed = correctCodeFragment.replace(/\s+/g, " ").trim();
  const selectedTrimmed = selectedOption.replace(/\s+/g, " ").trim();

  if (selectedTrimmed === correctTrimmed) {
  setIsCorrectLocal(true);
  setFeedback(
    "<span style='color: black; font-weight: bold; padding: 3px;'>Correct! fgets() prevents buffer overflow by limiting input. Try again with the same input.</span>"
  );
  setIsCorrect(true);
  setShowBuffer(false);

  // ✅ NEW: Notify parent simulation step is completed
  window.parent.postMessage(
    {
      type: "simulationProgress",
      step: "step-buffer-fix", // You can rename this to whatever step name you want
    },
    "*"
  );
}

};


  return (
    <div className="App">
      {!isCorrectLocal && (
        <div className="code-container">
          <h5>Vulnerable Code</h5>
          <div
            className="code-block"
            style={{
              height: "300px",
              maxWidth: "550px",
              overflowX: "hidden", // Prevent horizontal scroll
              overflowY: "auto",  // Vertical scroll only when needed
            }}
          >
            <SyntaxHighlighter
              language="c"
              style={docco}
              wrapLines={true}
              customStyle={{ whiteSpace: "pre-wrap" }} // Wrap lines instead of horizontal scroll
              lineProps={(lineNumber) => {
                const lines = vulnerableCode.split("\n");
                const lineText = lines[lineNumber - 1] || "";
                return {
                  style: lineText.includes("gets(buffer);")
                    ? { backgroundColor: "#ffcccc", color: "black", fontWeight: "bold", padding: "2px" }
                    : {},
                };
              }}
            >
              {vulnerableCode}
            </SyntaxHighlighter>
          </div>
        </div>
      )}
      {isCorrectLocal && (
        <div className="code-container">
          <h5>Corrected Code</h5>
          <div
            className="code-block"
            style={{
              height: "300px",
              maxWidth: "550px",
              overflowX: "hidden", // Prevent horizontal scroll
              overflowY: "auto",  // Vertical scroll only when needed
            }}
          >
            <SyntaxHighlighter
              language="c"
              style={docco}
              wrapLines={true}
              customStyle={{ whiteSpace: "pre-wrap" }} // Wrap lines
            >
              {correctedCodeBefore}
            </SyntaxHighlighter>
            <div
              style={{
                backgroundColor: "#ccffcc",
                color: "black",
                fontWeight: "bold",
                padding: "2px 5px",
                margin: "0",
                fontFamily: "monospace",
                whiteSpace: "pre-wrap", // Wrap highlighted line
                width: "100%",
              }}
            >
              {highlightLine}
            </div>
            <SyntaxHighlighter
              language="c"
              style={docco}
              wrapLines={true}
              customStyle={{ whiteSpace: "pre-wrap" }} // Wrap lines
            >
              {correctedCodeAfter}
            </SyntaxHighlighter>
          </div>
        </div>
      )}
      <div className="editor-container">
        <h5>Fix the Code</h5>
        <div className="hint">
          <p>Hint: Use fgets instead of gets to safely read input.</p>
          <select
            onChange={(e) => {
              setSelectedOption(e.target.value);
              setFeedback("");
            }}
            value={selectedOption}
          >
            {options.map((option, index) => (
              <option key={index} value={option}>
                {option}
              </option>
            ))}
          </select>
        </div>
        <button onClick={checkCode} className="check-button">
          Check Code
        </button>
        {feedback && <p dangerouslySetInnerHTML={{ __html: feedback }}></p>}
      </div>
    </div>
  );
}

export default Code;