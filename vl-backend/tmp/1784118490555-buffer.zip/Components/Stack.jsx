// import React, { useEffect, useState } from 'react';
// import { Canvas } from "@react-three/fiber";
// import { Html, OrbitControls, Box } from "@react-three/drei";
// import { useSelector } from "react-redux";
// import { FaInfoCircle } from 'react-icons/fa';
// import { useSpring, animated } from 'react-spring';

// const Stack = () => {
//   const { text } = useSelector((state) => state.md);
//   const [showInfo, setShowInfo] = useState(false);
//   const [showText, setShowText] = useState(false);
//   const [showFinalAddress, setShowFinalAddress] = useState(false);

//   const toggleInfo = () => {
//     setShowInfo(!showInfo);
//   };

//   useEffect(() => {
//     const timer = setTimeout(() => {
//       setShowText(true);
//     }, 4000);

//     const addressTimer = setTimeout(() => {
//       setShowFinalAddress(true);
//     }, 12000);

//     return () => {
//       clearTimeout(timer);
//       clearTimeout(addressTimer);
//     };
//   }, []);

//   const lastBit = text[text.length - 1];
//   const Hex = lastBit.split('').map(char => char.charCodeAt(0).toString(16).padStart(2, '0')).slice(0, 8).join(' ');
//   const finalAddress = ` 0x001780${Hex}`;

//   const { address, color } = useSpring({
//     address: showFinalAddress ? finalAddress : '0x00178010',
//     color: showFinalAddress ? 'red' : '#735E02',
//     config: { duration: 2000 },
//   });

//   return (
//     <div style={{ padding: '20px' }}>
//       <div style={{ display: 'flex', justifyContent: 'flex-end', position: 'relative' }}>
//         <FaInfoCircle
//           onClick={toggleInfo}
//           style={{
//             fontSize: '24px',
//             cursor: 'pointer',
//             position: 'fixed',
//             top: '20px',
//           }}
//         />
//         {showInfo && (
//           <div style={{
//             position: 'fixed',
//             top: '60px',
//             padding: '10px',
//             border: '1px solid #ddd',
//             borderRadius: '4px',
//             backgroundColor: 'white',
//             width: '250px'
//           }}>
//             <p>
//               The stack is aligned as pairs of 8 Bytes in memory. Since the size of the buffer here is 8 bytes, another 8 bytes are required after the buffer to reach the return address for overwriting it. Consider these 8 bytes as the distance between the buffer and the return address. This is known as stack alignment.
//             </p>
//           </div>
//         )}
//       </div>
//       <div style={{}}>
//         <Canvas
//           orthographic
//           camera={{ zoom: 60, position: [4, 2, 20] }}
//           style={{ width: "20vw", height: "40vh" }}
//         >
//           <ambientLight intensity={0.3} />
//           <directionalLight position={[0, 10, 5]} intensity={1.0} />
//           <pointLight position={[10, 10, 10]} intensity={0.5} />
//           <OrbitControls />
//           <Box position={[0, 0, 0]} args={[3, 5, 2]}>
//             <meshBasicMaterial color="blue" transparent opacity={0.2} />
//             <Box position={[0, 1.5, 0]} args={[2, 1, 2]}>
//               <Html position={[-.8, 0, -1]}>
//                 <div
//                   style={{
//                     color: "#735E02",
//                     fontSize: "12px",
//                     fontWeight: "bold",
//                   }}
//                 >
//                   Buffer
//                   0x00178000
//                 </div>
//               </Html>
//             </Box>
//             <Box position={[0, 0, 0]} args={[2, 1, 2]}>
//               <Html position={[-.8, .2, -1]}>
//                 <div
//                   style={{
//                     color: "#735E02",
//                     fontSize: "12px",
//                     fontWeight: "bold",
//                   }}
//                 >
//                   Stack Alignment
//                   (8Bytes)
//                 </div>
//               </Html>
//             </Box>
//             <Box position={[0, -1.3, 0]} args={[2, 1, 2]}>
//               <Html position={[-.8, .3, -1]}>
//                 <div
//                   style={{
//                     color: "#735E02",
//                     fontSize: "12px",
//                     fontWeight: "bold",
//                   }}
//                 >
//                   Return Address
//                 </div>
//               </Html>
//               <Html position={[-.8, -.3, -1]}>
//                 <animated.div
//                   style={{
//                     color: color,
//                     fontSize: "12px",
//                     fontWeight: "bold",
//                   }}
//                 >
//                   {address}
//                 </animated.div>
//               </Html>
//             </Box>
//             <Html position={[-.8, -2, -1]}>
//                 <div
//                   style={{
//                     color: "#735E02",
//                     fontSize: "15px",
//                     fontWeight: "bold",
//                   }}
//                 >
//                   Stack
//                 </div>
//               </Html>
//           </Box>
//         </Canvas>
//         {showFinalAddress&&(<div
//           style={{
//             color: "#735E02",
//             fontSize: "12px",
//             fontWeight: "bold",
//           }}
//         >
                 

//           Buffer overflows can overwrite the return address in memory, directing the program to unintended locations by manipulating input data.
//         </div>)}
        
//       </div>
//     </div>
//   );
// }

// export default Stack;
import React from 'react';

const Stack = () => {
  return (
    <div>
      
    </div>
  );
}

export default Stack;
