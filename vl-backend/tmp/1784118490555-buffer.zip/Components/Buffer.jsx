import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

const BufferOverflowVisualization = () => {
  const { text } = useSelector((state) => state.md);
  const bufferSize = 16; // 4 columns x 4 rows
  const ebpSize = 4;
  const eipSize = 4;
  const totalSize = bufferSize + ebpSize + eipSize;
  const [winMessage, setWinMessage] = useState('');
  const savedEbp = '43d3f981'; // Fixed EBP value

  useEffect(() => {
    console.log('hello');
    // Check if positions 21-24 are '\x18\x50\x80\x17'
    if (text.length >= 24 && text.slice(20, 36) === '\\x18\\x50\\x80\\x17') {
      setWinMessage(
        'Return address has been overwritten successfully with the address of win. Good job!'
      );
    } else {
      setWinMessage('');
    }
  }, [text]);

  const getCellColor = (index) => {
    if (index >= bufferSize + ebpSize) return '#FF6347'; // Color for EIP
    if (index >= bufferSize) return '#FFD700'; // Color for EBP
    return '#61AFEF'; // Color for buffer
  };

  const values = Array.from({ length: totalSize }, (_, i) => {
    if (i >= text.length) {
      if (i >= bufferSize && i < bufferSize + ebpSize) {
        return savedEbp.slice((i - bufferSize) * 2, (i - bufferSize + 1) * 2); // Return fixed EBP value
      }
      return '00'; // Default value if no input
    }

    // Handle EIP slots (last 4 positions)
    if (i >= bufferSize + ebpSize) {
      // EIP slots are the last 4 characters, so we extract the corresponding part of the text
      const eipIndex = i - (bufferSize + ebpSize);
      const startIndex = bufferSize + ebpSize + eipIndex * 4;
      const slice = text.slice(startIndex, startIndex + 4);
      if (slice.startsWith('\\x')) {
        return slice.slice(2); // remove the '\x' prefix and display the value
      }
      return '00'; // default if not in expected format
    }

    const charCode = text.charCodeAt(i);
    return isNaN(charCode) ? '00' : charCode.toString(16).padStart(2, '0');
  }).reverse();

  return (
    <div className="visualization-container">
      <div className="memory-container">
        <div className="eip-grid">
          {values.slice(0, eipSize).map((value, i) => (
            <div
              key={i}
              className="buffer-cell"
              style={{ backgroundColor: getCellColor(bufferSize + ebpSize + i) }}
            >
              {value}
              
            </div>
          ))}
        </div>
        <div className="label">Saved EIP</div>
        <div className="ebp-grid">
          {values.slice(eipSize, eipSize + ebpSize).map((value, i) => (
            <div
              key={i}
              className="buffer-cell"
              style={{ backgroundColor: getCellColor(bufferSize + i) }}
            >
              {value}
            </div>
          ))}
        </div>
        <div className="label">Saved EBP</div>
        <div className="buffer-grid">
          {values.slice(eipSize + ebpSize).map((value, i) => (
            <div
              key={i}
              className="buffer-cell"
              style={{ backgroundColor: getCellColor(i) }}
            >
              {value}
            </div>
          ))}
        </div>
        <div className="label">Buffer (16 bytes)</div>
        <div className="label">Main Stack</div>
        {winMessage && (
          <div className="win-message">
            {winMessage}
            <div className="fix-instruction">Fix the code to stop buffer overflow!</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BufferOverflowVisualization;
