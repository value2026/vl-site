import React from 'react';
import styled from 'styled-components';
import { FaExclamationTriangle } from 'react-icons/fa';

const DialogOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 120vh;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 5
`;


const DialogBox = styled.div`
background: white;
border: 2px solid #EEEEEE;
width: 400px;
padding: 20px;
box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
font-family: Tahoma, sans-serif;
position: relative;
z-index: 99999
&::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 1px solid black;
  box-sizing: border-box;
  pointer-events: none;
}
`;


const DialogHeader = styled.div`
  display: flex;
  align-items: center;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
`;

const IconWrapper = styled.div`
  margin-right: 10px;
  color: red;
`;

const DialogMessage = styled.div`
  margin-bottom: 20px;
`;

const DialogFooter = styled.div`
  display: flex;
  justify-content: flex-end;
`;

const DialogButton = styled.button`
  background: lightgray;
  border: 1px solid gray;
  padding: 5px 10px;
  cursor: pointer;
  &:hover {
    background: gray;
    color: white;
  }
`;

const WarningDialog = ({ message, onClose }) => {
  return (
    <DialogOverlay>
      <DialogBox>
        <DialogHeader>
          <IconWrapper>
            <FaExclamationTriangle size={24} />
          </IconWrapper>
          Buffer overrun detected
        </DialogHeader>
        <DialogMessage>{message}</DialogMessage>
        <DialogFooter>
          <DialogButton onClick={onClose}>Fix</DialogButton>
        </DialogFooter>
      </DialogBox>
    </DialogOverlay>
  );
};

export default WarningDialog;
