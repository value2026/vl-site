import React from 'react';
import styled from 'styled-components';

const StackContainer = styled.div`
  background-color: black;
  color: green;
  font-family: monospace;
  padding: 10px;
  border: 1px solid green;
`;

const StackRow = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 5px;
  ${(props) => props.isOverflow && `
    color: green
    font-weight: bold;
  `}
`;

const LabelRow = styled.div`
  display: flex;
  justify-content: flex-start;
  margin-bottom: 5px;
  color: yellow;
  &:after {
    content: '->';
    margin-left: 5px;
    color: white;
  }
`;

const Column = styled.div`
  flex: 1;
  text-align: left;
  padding: 0 10px;
  &:nth-child(1) {
    flex: 0.5;
  }
  &:nth-child(2) {
    flex: 2;
  }
  &:nth-child(3) {
    flex: 2.5;
  }
  &:nth-child(4) {
    flex: 2;
  }
  &:nth-child(5) {
    flex: 2;
  }
`;

const formatHex = (value) => {
  return value.split('').map(char => char.charCodeAt(0).toString(16).padStart(2, '0')).slice(0, 8).join(' ');
};

const formatAscii = (value) => {
  return value.replace(/[^ -~]/g, '.').slice(0, 8);
};

const formatAddress = (address) => {
  return `0x${address.toString(16).padStart(8, '0')}`;
};

const Stack = ({ stack }) => (
  <StackContainer>
    {stack.slice(0, 1).map((row, index) => (
      <StackRow key={index} isOverflow={row.data !== '0000000000000000'}>
        <Column></Column>
        <Column style={{ color: 'cyan' }}>{formatAddress(row.address)}</Column>
        <Column>
          <LabelRow>Buffer</LabelRow>
        </Column>
        <Column>{formatHex(row.data)}</Column>
        <Column>{formatAddress(row.address)}</Column>
      </StackRow>
    ))}
    
    {stack.slice(1, 2).map((row, index) => (
      <StackRow key={index}>
        <Column></Column>
        <Column style={{ color: 'cyan' }}>{formatAddress(row.address)}</Column>
        <Column>
          <LabelRow>Stack alignment</LabelRow>
        </Column>
        <Column>{formatHex('4141414141414141')}</Column> 
        <Column>{formatAddress(row.address)}</Column>
      </StackRow>
    ))}
   
    {stack.slice(2, 3).map((row, index) => (
      <StackRow key={index} isOverflow={true}> 
        <Column></Column>
        <Column style={{ color: 'cyan' }}>{formatAddress(row.address)}</Column>
        <Column>
          <LabelRow>Return Address</LabelRow>
        </Column>
        <Column>{formatHex('deadbeefdeadbeef')}</Column> 
        <Column>{formatAddress(row.address)}</Column>
      </StackRow>
    ))}
  </StackContainer>
);

export default Stack;
