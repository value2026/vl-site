import React from 'react';
import { useSelector } from 'react-redux';
import styled from 'styled-components';
import BufferOverflow from './updatedBufferoverflow';

const AppContainer = styled.div`
  display: flex;
  flex-direction: column;
  background-color: black;
  padding: 20px;
`;

const InputContainer = styled.div`
  margin: 10px 0;
`;

const TextInput = styled.input`
  padding: 5px;
  font-family: monospace;
  color: green;
  background-color: black;
  border: 1px solid green;
`;

const UpdatedRadare = () => {
  const { text } = useSelector((state) => state.md);

  return (
    <AppContainer>
    
     <BufferOverflow/>
      
    </AppContainer>
  );
};

export default UpdatedRadare;
