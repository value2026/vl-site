import React from 'react';
import styled from 'styled-components';
import { useSelector } from 'react-redux';

const UpdatedregisterContainer = styled.div`
  display: flex;
  flex-direction: column;
  background-color: black;
  color: green;
  font-family: monospace;
  padding: 10px;
  border: 1px solid green;
  margin-bottom: 10px;
`;

const RegisterRow = styled.div`
  display: flex;
  justify-content: space-between;
  color: ${props => props.color || 'inherit'};
`;

const Updatedregister = () => {
  const { text } = useSelector((state) => state.md);
  let ripAddress;
  let ripColor = 'green'; 
  if (text.length <= 8) {
    ripAddress = '0x00178000';
  } else if (text.length > 8 && text.length <= 16) {
    ripAddress = '0x00178008';
    ripColor = 'green'; 
  } else {
    ripAddress = '0x00178010';
    ripColor = 'green'; 
  }

  return (
    <UpdatedregisterContainer>
      <RegisterRow><div>rax:</div><div>0x00000000</div></RegisterRow>
      <RegisterRow><div>rbx:</div><div>0x00000000</div></RegisterRow>
      <RegisterRow><div>rcx:</div><div>0x00000000</div></RegisterRow>
      <RegisterRow><div>rdx:</div><div>0x00000000</div></RegisterRow>
      <RegisterRow><div>rsi:</div><div>0x00000000</div></RegisterRow>
      <RegisterRow><div>rdi:</div><div>0x00000000</div></RegisterRow>
      <RegisterRow><div>rsp:</div><div>0x00177ff8</div></RegisterRow>
      <RegisterRow><div>rbp:</div><div>0x00177ff8</div></RegisterRow>
      <RegisterRow color={ripColor}><div>rip:</div><div>0x00178000</div></RegisterRow>
      <RegisterRow><div>rflags:</div><div>0x00000000</div></RegisterRow>
    </UpdatedregisterContainer>
  );
};

export default Updatedregister;
