import React, { useState } from "react";
import { connect } from "react-redux";
import { updateText } from "../redux/InputReducer";
import { FaCopy } from "react-icons/fa";

const bufferOverflowContent = [
  {
    title: "What is a buffer?",
    content:
      "A buffer is a temporary storage area typically used to hold data while it is being transferred from one place to another. Buffers are used in many aspects of programming and hardware to handle data more efficiently.",
  },
  {
    title: "What is saved EBP?",
    content:
      "Saved EBP (Base Pointer) is a register that holds the base address of the stack frame. It helps in accessing function parameters and local variables within a stack frame. During a buffer overflow, the saved EBP can be overwritten, which can lead to control flow hijacking.",
  },
  {
    title: "What is saved EIP?",
    content:
      "Saved EIP (Instruction Pointer) is a register that holds the address of the next instruction to be executed. In the context of buffer overflow, attackers often aim to overwrite the saved EIP to redirect the execution flow to malicious code.",
  },
  {
    title: "How does buffer overflow occur?",
    content:
      "Buffer overflow occurs when data exceeds the buffer's storage capacity, causing data to overwrite adjacent memory. This can lead to unexpected behavior, crashes, or even the execution of malicious code.",
  },
  {
    title: "Why is buffer overflow dangerous?",
    content:
      "Buffer overflow is dangerous because it can allow attackers to execute arbitrary code, gain unauthorized access, or crash a system. It exploits a vulnerability in the code, making it a common target for attacks.",
  },
  {
    title: "How to prevent buffer overflow?",
    content:
      "To prevent buffer overflow, ensure proper bounds checking, use safe functions that limit the amount of data written to a buffer, and employ modern programming languages or compiler options that include built-in protections.",
  },
  {
    title: "What is little-endian?",
    content:
      "In little-endian format, the least significant byte (the 'little end') is stored first. For example, the hexadecimal value 0x17805018 is stored in memory as 0x18, 0x50, 0x80, 0x17. This is important for correctly exploiting the buffer overflow to ensure the win function address is interpreted correctly.",
  },
];

const Input = ({ updateText }) => {
  const [inputValue, setInputValue] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [openAccordion, setOpenAccordion] = useState(null);
  const [copied, setCopied] = useState(false);

  const handleChange = (e) => {
    const value = e.target.value;

    if (value.length > 20) {
      const after20th = value.slice(20);
      if (!/^\\x[0-9A-Fa-f]{2}/.test(after20th)) {
        setErrorMessage("Please enter the win function address in \\x format.");
        return;
      }
    }

    setInputValue(value);
    setErrorMessage("");
    updateText(value);
  };

  const toggleAccordion = (index) => {
    setOpenAccordion(openAccordion === index ? null : index);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText("\\x18\\x50\\x80\\x17");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      style={{
        backgroundColor: "#3CA4AB",
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "20px",
        boxSizing: "border-box",
      }}
    >
      <div
        style={{
          color: "white",
          padding: "10px",
          borderRadius: "5px",
          textAlign: "center",
          marginTop: "20px",
        }}
      >
        <h5 style={{ margin: "0" }}>Buffer Overflow</h5>
      </div>

      {/* Scrollable Accordion Section */}
      <div
        style={{
          width: "80%",
          marginTop: "20px",
          height: "150px", // Approx height for 3 items (adjust as needed)
          overflowY: "auto", // Enable vertical scrolling
          overflowX: "hidden", // Prevent horizontal scrolling
        }}
      >
        {bufferOverflowContent.map((accordion, index) => (
          <div
            key={index}
            style={{
              marginBottom: "10px",
              borderRadius: "5px",
              backgroundColor: "#2A8C94",
              padding: "6px",
              cursor: "pointer",
              transition: "background-color 0.3s",
              boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
            }}
            onClick={() => toggleAccordion(index)}
          >
            <div
              style={{ fontWeight: "bold", color: "white", fontSize: "80%" }}
            >
              {accordion.title}
            </div>
            {openAccordion === index && (
              <div style={{ marginTop: "5px", color: "white" }}>
                {accordion.content}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Instructions Section */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          width: "80%",
          marginTop: "20px",
        }}
      >
        <h6
          style={{
            color: "white",
            textAlign: "center",
            marginBottom: "5px",
          }}
        >
          Instructions
        </h6>
        <div
          style={{
            backgroundColor: "#3CA4AB",
            color: "white",
            borderRadius: "5px",
            padding: "10px",
            boxShadow: "0 2px 4px rgba(0, 0, 0, 0.2)",
          }}
        >
          <p style={{ textAlign: "left", width: "100%", fontSize: "80%" }}>
            To exploit the buffer overflow vulnerability in the provided code and
            successfully call the win function located at the address:
            <code>0x17805018</code>, follow these steps:
            <ol>
              <li>
                First, input 16 bytes to fill the buffer. Although the buffer is defined
                with a 16-byte limit, it is not inherently constrained, allowing the
                buffer to overflow into adjacent memory.
              </li>
              <li>
                Next, overwrite the saved EBP with 4 bytes, followed by 4
                bytes for the saved EIP. Input the address of the win
                function in little-endian format as follows:{" "}
                <code>
                  \x18\x50\x80\x17{" "}
                  <FaCopy
                    onClick={copyToClipboard}
                    style={{ cursor: "pointer", color: "white" }}
                  />
                </code>
              </li>
            </ol>
            This little-endian address format corresponds to the location of the
            win function (0x17805018). By injecting this address into the
            overflowed buffer, the system will redirect execution to the win
            function, effectively triggering its execution.
          </p>
        </div>
      </div>

      {/* Input Section - Always Visible */}
      <div
        style={{
          width: "80%",
          textAlign: "center",
          marginTop: "20px",
          marginBottom: "20px",
          flexGrow: 1, // Allows this section to take available space
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "flex-start",
        }}
      >
        <div style={{ marginBottom: "10px", color: "white" }}>
          Enter your Text
        </div>
        <input
          type="text"
          className="form-control"
          style={{
            backgroundColor: "#3CA4AB",
            color: "white",
            border: "1px solid #cccccc",
            marginBottom: "10px",
            width: "100%",
            padding: "10px",
            borderRadius: "5px",
            height: "40px",
          }}
          value={inputValue}
          onChange={handleChange}
        />
        {errorMessage && (
          <div style={{ color: "yellow", marginBottom: "10px" }}>
            {errorMessage}
          </div>
        )}
      </div>
    </div>
  );
};

const mapStateToProps = (state) => ({
  text: state.md.text,
});

const mapDispatchToProps = {
  updateText,
};

export default connect(mapStateToProps, mapDispatchToProps)(Input);