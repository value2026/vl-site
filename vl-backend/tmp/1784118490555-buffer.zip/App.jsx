import React, { useState } from "react";
import "./App.css";
import Buffer from "./Components/Buffer";
import Code from "./Components/Code";
import Input from "./Components/Input";
import UpdatedInput from "./Components/UpdatedInput";
import Stack from "./Components/Stack";
import UpdatedBuffer from './Components/UpdatedBuffer'
import RadarApp from "./Components/Radare/MainComponent";
import UpdatedRadare from "./Components/UpdatedRadare/UpdatedMain";

function App() {
  const [showWarning, setShowWarning] = useState(false);
  const [hideContent, setHideContent] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showBuffer, setShowBuffer] = useState(true);
  const [showBuffers, setShowBuffers] = useState(false);
  const [shake, setShake] = useState(true);
  const [activeView, setActiveView] = useState('buffer');

  const handleCloseWarning = () => {
    setShowWarning(false);
    setHideContent(true);
    setShake(false);
  };

  const handleGenerateClick = () => {
   
  };
  const handleGenerateClicks = () => {
    setShowBuffers(true);
  };

  return (
    <>
      <div className="row">
        <div className="col-md-4">
          {!isCorrect && <Input onGenerate={handleGenerateClick} />}
          {isCorrect && <UpdatedInput onGenerate={handleGenerateClicks} />}
        </div>
        <div className="col-md-5">
          <div className="button-group">
            {/* <button style={{margin:'20px'}}
              className={`btn ${activeView === 'buffer' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setActiveView('buffer')}
            >
              Show Buffer
            </button>
            <button
              className={`btn ${activeView === 'radar' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setActiveView('radar')}
            >
              Show Radare2
            </button> */}
          </div>
          {activeView === 'buffer' && (
            <>
              {showBuffer && (
                <>
                <div className="row">

                  <Buffer
                  showWarning={showWarning}
                  onCloseWarning={handleCloseWarning}
                  hideContent={hideContent}
                  setShowWarning={setShowWarning}
                  setIsCorrect={setIsCorrect}
                  setShake={setShake}
                />
                {/* <Stack /> */}
                </div>
                {/* <div className="col-4">  <Stack /></div> */}
              
              
                
                  </>
               )}  
              {showBuffers && (
                <UpdatedBuffer
                  showWarning={showWarning}
                  onCloseWarning={handleCloseWarning}
                  hideContent={hideContent}
                  setIsCorrect={setIsCorrect}
                />
              )}
            </>
          )}
           
          {activeView === 'radar' &&(
            <>
            {showBuffer && (
              <RadarApp/>
          )}
           {showBuffers && (
            <UpdatedRadare />
          )}
            </> )}
        
        </div>
        <div className="col-md-3">
          {/* {hideContent && ( */}
            <Code setIsCorrect={setIsCorrect} setShowBuffer={setShowBuffer} />
          {/* )} */}
          
        
      
        </div>
      </div>
    </>
  );
}

export default App;
