
import { configureStore } from "@reduxjs/toolkit";

import mdReducer from './InputReducer'
const store = configureStore({
    reducer: {
        md: mdReducer
    }
})
export default store