import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  text: '',
  detailText: '',
};

const inputReducer = createSlice({
  name: 'inputReducer',
  initialState,
  reducers: {
    updateText: (state, action) => {
      return {
        ...state,
        text: action.payload
      }
    },
    
  }
});

export const { updateText } = inputReducer.actions;
export default inputReducer.reducer;
